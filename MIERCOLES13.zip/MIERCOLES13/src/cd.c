#include "../inc/minishell.h"

static void	change_dir(char *path, t_shell *param)
{
	char		cwd[4097];
	char		oldpwd[4097];

	getcwd(oldpwd, 4096);
	if (chdir(path) == 0)
	{
		param->argc = 4;
		ft_free_matrix(param->argv);
		param->argv = (char **)ft_calloc(sizeof(char *), 4);
		param->argv[0] = ft_strdup("export");
		param->argv[1] = ft_strdup("OLDPWD=");
		param->argv[2] = ft_strdup(oldpwd);
		param->envp = export_command(param, 1);
		ft_free_matrix(param->argv);
		param->argv = (char **)ft_calloc(sizeof(char *), 4);
		param->argv[0] = ft_strdup("export");
		param->argv[1] = ft_strdup("PWD=");
		param->argv[2] = ft_strdup(getcwd(cwd, 4096));
		param->envp = export_command(param, 1);
	}
}

void		cd_command(t_shell *param)
{
	char	*path;

	path= NULL;
	errno = 0;
	if (param->argc == 1)
	{
		path = get_env(param->envp, "HOME");
		if (!ft_strncmp(path, "", 1))
		{
			ft_putstr_fd("HOME not set\n", 2);
			return ;
		}
	}
	else if (param->argc >= 2)
	{
		if (param->argv[1] && !ft_strncmp(param->argv[1], "--", 3))
			path = get_env(param->envp, "HOME");
		else if (param->argv[1] && !ft_strncmp(param->argv[1], "~", 2))
			path = get_env(param->envp, "HOME");
		else if (param->argv[1] && !ft_strncmp(param->argv[1], "-", 2))
		{
			path = get_env(param->envp, "OLDPWD");
			if (!ft_strncmp(path, "", 1))
			{
				ft_putstr_fd("OLDPWD not set\n", 2);
				param->ret = 1;
				return ;
			}
			else
				path = get_env(param->envp, "OLDPWD");
		}
		else if (param->argv[1] && !ft_strncmp(param->argv[1], "", 1))
		{
			path = getcwd(NULL, 0);
			mini_setenv("OLDPWD", path, param->envp, 6);
			return ;
		}
		else if (param->argv[1] && !ft_strncmp(param->argv[1], "//", 3))
		{
			path = "//";
			mini_setenv("PWD", path, param->envp, 3);
		}
		else
			path = param->argv[1];
		param->ret = 0;
	}
	change_dir(path, param);
	if (errno > 0)
	{
		ft_putstr_fd(strerror(errno), 2);
		ft_putstr_fd("\n", 2);
		param->ret = 1;
	}
	errno = 0;
}
