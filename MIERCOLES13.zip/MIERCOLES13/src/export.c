#include "../inc/minishell.h"
void reloko(t_shell *param, int j)
{

//	printf("RELOKO NETRANDOOO%s\n", param->argv[j+1]);
///printf("%d", j);
	if (ft_strchr(param->argv[j+1], '$') == NULL)
		return ;
	rm_char(&param->argv[j+1], 0);
	if(mini_getenv( param->argv[j+1], param->envp, j) == NULL) //&& ft_strlen(param->argv[j+1])!=0)
	{

		if(ft_strlen(param->argv[j+1]) == 0)
			param->argv[j+1]= ft_strdup("$");
		else
			param->argv[j+1]= ft_strdup("");
		return ;
	}
	else
	param->argv[j+1] = mini_getenv( param->argv[j+1], param->envp, j);

}
char		**export_command(t_shell *param, int j)
{
	int		i;
	char	**cpy;
	char *aux;

	aux="";

	i = 0;
	reloko(param, j);

	while (param->envp[i] && ft_memcmp(param->envp[i],
			param->argv[j], ft_strlen(param->argv[j])))
		i++;
	if (!param->envp[i])
	{
		cpy = copy_env(param->envp, 1);
		cpy[i] = ft_strjoin(param->argv[j], param->argv[j + 1]);
	}
	else
	{
		cpy = param->envp;
		aux = ft_strjoin(param->argv[j], param->argv[j + 1]);
		param->envp[i] = ft_strdup(aux);
		free(aux);
	}
	return (cpy);
}

void		export_value(t_shell *param, int *i)
{
	char	**aux;
	int		j;

	//printf("%d\n", *i);
	if (!ft_strchr(param->argv[*i], '='))
	{
		j = 0;
		while (param->export[j])
		{
			if(ft_memcmp(param->export[j], param->argv[*i], ft_strlen(param->argv[*i])))
				j++;
		}
		if (!param->export[j])
		{
			aux = copy_env(param->export, 1);
			aux[j] = ft_strdup(param->argv[*i]);
			aux[j + 1] = 0;
			ft_free_matrix(param->export);
			param->export = aux;
		}
		(*i)++;
	}
	else
	{
		param->envp = export_command(param, *i);
		*i += param->argv[*i + 1] ? 2 : 1;
	}
}

char *mini_check(char *value)
{
//	puts(value);
	int found;
	found = ft_strchr_i(value, '=');
	
	if (value[found-1] == ' ' || value[found-1] == '$')
		return (NULL);
	/*while (value[--found])
	{
		if (value[found] == '$')
		{
			rm_char(&value,found);
			printf("otroooo%c", value[found]);
		}

	}*/
	return (value);
}

char *get_var(char *str, int found)
{
	char *value;
	int ini;
	int fi;
	int i;
	int j;

	j=0;
	ini=0;
	fi=0;
	i=0;
	//printf("f:%d\n", found);
	//ini = ft_strchrl(str, ' ', ini, found) + 1;
//	printf("caraacter ini:%c\n", str[found]);
	j = found;
	while(str[found] != '=')
		found++;
//	printf("caraacter ini:%c\n", str[found]);
	if (str[found+1] == '\"')
	{
		rm_char(&str,found+1);
		i=-1;
	}
	found = j;
	while(str[found] != ' ')
		found--;
	ini = found+1;
	//printf("ini:%d\n", ini);
	if (i== 0)
	{
	//	puts("entra");
		fi = ft_strchrl(str, ' ', ini+1, ft_strlen(str))-1;
	}
	else
		fi= ft_strchrl(str, '\"', ini+1, ft_strlen(str))-1;
	value = ft_substr(str, ini, fi-ini+1);
//	printf("elvaluedemierda es%s", value);

	return (value);
}
void add_argv(t_shell *shell, char *value, int i, int flag)
{
	char *val;
	int x;

	x =0;
//	printf("nodoymas%s", value);
	if (flag == 15)
	{
		free(shell->argv[i]);
		shell->argv[i] = ft_strdup("*");
		free(shell->argv[i+1]);
		shell->argv[i+1] = ft_strdup("*");
	}
	else
	{
	int found;
	found = ft_strchr_i(value, '=');
	
	if (value[found-1] == ' ' || value[found-1] == '$')
		return ;

	x = found;
	while (value[--found])
	{
		if (value[found] == '$')
			break;
	}
	if (found < 0)
		{
		free(shell->argv[i]);
		shell->argv[i] = ft_substr(value, 0, ft_strchr_i(value, '=')+1);
	//	printf("elque entra es%s", shell->argv[i]);
		val =  ft_substr(value, (ft_strchr_i(value, '=')+1), ft_strlen(value));
		free(shell->argv[i+1]);
		shell->argv[i+1] = val;
//	printf("otroooo%s-----\n", val);
//			printf("otraaaa%s", shell->argv[i]);
found =-1;
		}
	else
	{
//	printf("elque entra es%s", value);

		val =ft_substr(value,found, x-found);

	//	printf("elprimero%s-----\n", val);
		rm_char(&val, 0);
		if(mini_getenv( val, shell->envp, 0) == NULL) //&& ft_strlen(param->argv[j+1])!=0)
				val= ft_strdup("");
		else
			val = mini_getenv( val, shell->envp, 0);
	//	printf("elprimero%s-----\n", val);
		x = -1;
while (val[++x])
{
			if (ft_isalnum((int)val[x]) == 0 && val[x] != '=') //ARREGLADOOOO SOLO DAR ERROR y que siga viendo los siguientes!
			{
				value = "*";
			//	puts("telodije");
						ft_putstr_fd("bash: line 0: export: `", 2);
						ft_putstr_fd("': not a valid identifier\n", 2);
						shell->ret = 1;
						break ;

			//	return ;
			}
}

			free(shell->argv[i]);
			shell->argv[i] = ft_strjoin(ft_substr(value, 0, ft_strchr_i(value, '$')), val);
			free(val);
			val = ft_strjoin(shell->argv[i], "=");

		//	printf("etequedaaa%s-----\n", val);
			free(shell->argv[i]);
			shell->argv[i] = ft_strdup(val);
			free(val);
			val =  ft_substr(value, (ft_strchr_i(value, '=')+1), ft_strlen(value));
			free(shell->argv[i+1]);
			shell->argv[i+1] = val;
		//	printf("otroooo%s-----\n", val);
		//	printf("otraaaa%s", shell->argv[i]);
		}
/* REVISAR QUE CUANDO DEVUELVA ALGO QUE TENGA / / O LA CHOTA NO LO HAGA*/
	}
}

int		check_export_error(t_shell	*shell, int times)
{
	int found;
	int i;

	int j;
	char *value;
	char *str;
	i = 0;
	j=0;

	found = 0;
	str = shell->str;
	if (found >= 0)
	{
		while(i <(times*2))
		{

		shell->ret = 0;
			shell->ret = 0;
			while (str[j] != '=')
					j++;
			found = j;
			//printf("found:%d\n", found);
			if (ft_isspace(str[found -1]) || ft_isspace(str[found +1]))
			{
			//	puts("chimuelo");
				value = ft_substr(str, found, ft_strlen(&str[found]));
				ft_putstr_fd("bash: export: `", 2);
				write(2,&str[found-1], 1);
			//	ft_putstr_fd(value, 2);
				ft_putstr_fd(": not a valid identifier\n", 2);
				add_argv(shell, value, i, 15);
				shell->ret = 1;
			}
			if (ft_isdigit(str[found -1])&& !ft_isspace(str[found +1]))//&& ft_isdigit(str[found -2] ))
			{
					while(str[found- 1] != ' ')
					{
						if (ft_isalnum(str[found-1]) == 0 && str[found-1] != '$')
							shell->ret = 1;
						if (shell->ret == 1)
							break ;
						found --;
					}
					if (ft_isalpha((int)str[found]) == 0)
					{
						value = ft_substr(str, found-1, ft_strlen(&str[found])+1);
						ft_putstr_fd("bash: line 0: export: `", 2);
						write(2,&str[found], 1);
						ft_putstr_fd("': not a valid identifier\n", 2);
						add_argv(shell, value, i, 15);
						shell->ret = 1;
					}
					else
					{
					//	puts("chimulai");
						value = get_var(str, found);
						if (mini_check(value) != NULL)
							add_argv(shell, value, i, 0);
					}
			}

			else
			{
			
				//printf("elcaracterlocoes%c", str[found-1]);
				while(str[found- 1] != ' ')
					{
						if (ft_isalnum(str[found-1]) == 0 && str[found-1] != '$' )
						{
						value = ft_substr(str, found-1, ft_strlen(&str[found])+1);
						ft_putstr_fd("bash: line 0: export: `", 2);
						write(2,&str[found-1], 1);
						ft_putstr_fd("': not a valid identifier\n", 2);
						add_argv(shell, value, i, 15);
						shell->ret = 1;
						}
						found --;
					}

				if (shell->ret != 1)
					{
					//	puts("entra");
						value = get_var(str, found);
						if (mini_check(value) != NULL)
							add_argv(shell, value, i, 0);
						else
{
						value = ft_substr(str, found-1, ft_strlen(&str[found])+1);
						ft_putstr_fd("bash: line 0: export: `", 2);
						write(2,"$", 1);
						ft_putstr_fd("': not a valid identifier\n", 2);
						add_argv(shell, value, i, 15);
						shell->ret = 1;
						}

					}

			}
			j++;
			i +=2;
		}
		shell->argv[i] = NULL;
	}

	return (0);
}

static void	put_envp(char **aux, int fd)
{
	int i;

	i = -1;
	while (aux[++i])
	{
		ft_putstr_fd("declare -x ", fd);
		ft_putstrlen_fd(aux[i], ft_strlen_char(aux[i], '=') + 1, fd);
		if (ft_strchr(aux[i], '='))
		{
			ft_putstr_fd("\"", fd);
			ft_putstr_fd(ft_strchr(aux[i], '=') + 1, fd);
			ft_putstr_fd("\"", fd);
		}
		write(fd, "\n", 1);
	}
	ft_free_matrix(aux);
}

void	sort_envp(char **envp, int fd, char c)
{
	int		i;
	int		len;
	char	**aux;
	char	*tmp;

	aux = copy_env(envp, 0);
	i = 0;
	while (aux[i] && aux[i + 1])
	{
		len = (ft_strlen_char(aux[i], c) > ft_strlen_char(aux[i + 1], c))
				? ft_strlen_char(aux[i], c) : ft_strlen_char(aux[i + 1], c);
		if (ft_memcmp(aux[i], aux[i + 1], len) > 0)
		{
			tmp = aux[i];
			aux[i] = aux[i + 1];
			aux[i + 1] = tmp;
			i = -1;
		}
		i++;
	}
	put_envp(aux, fd);
}
//l=1 l2=2 l3 =3 l4=4
