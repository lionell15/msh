/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   signals.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lespinoz <lespinoz@student.42barcelona.com>+#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/13 12:16:48 by lespinoz          #+#    #+#             */
/*   Updated: 2022/07/14 13:29:46 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/minishell.h"

int	enter_ctrld(t_shell shell)
{
	int j = 0;
	printf("\x1b[1A");
	rl_on_new_line();
	rl_redisplay();
//	printf("exit\n");
	int i = -1;
	while (shell.envp[++i])
	j++;
		free(shell.envp[j]);
//		j--;
//	}
		//puts(shell.envp[i]);
	//	if (shell.envp[i][0] != '\0')
	//		free(shell.envp[i]);
//	free(shell.envp);
	shell.argc = 1;

	shell.piped = 0;
return(	exit_command(&shell), 0);
//	free (shell->envp);
//	free(shell->argv);	
//	return (1);
//	exit (1);
}

void    child_sig_handler(int sig)
{
	(void)sig;

//	puts("soyychild");
	//printf("child_sig_handler\n");
    ft_putstr_fd("^C\n", 2);
//	rl_replace_line("", 1);
	rl_on_new_line();
}

void    child_sig_handler_bash(int sig)
{
//	puts("soyyobash");
    (void)sig;
    //printf("child_sig_handler bash\n");
    //printf("mi id es: %d", getpid());
    ft_putstr_fd("^C\n", 2);
}

void    child_sig_handler_test(int sig)
{

//	puts("soyyitest");
    (void)sig;
}
void	signal_handler(int signo)
{
	if (signo == SIGINT)
	{
		printf("\n");
		rl_replace_line("", 1);
	}
	else if (signo == SIGQUIT)
	{
	//	rl_replace_line("", 1);
	}
	rl_on_new_line();
	rl_redisplay();
}

int	set_signal(void)
{
	struct termios	term;

	if (tcgetattr(STDIN_FILENO, &term) == -1)
		return (1);
	term.c_lflag &= ~(ECHOCTL);
	if (tcsetattr(STDIN_FILENO, TCSANOW, &term) == -1)
		return (1);
	if (signal(SIGINT, signal_handler) == SIG_ERR)
		return (1);
	if (signal(SIGQUIT, signal_handler) == SIG_ERR)
		return (1);
	return (0);
}
