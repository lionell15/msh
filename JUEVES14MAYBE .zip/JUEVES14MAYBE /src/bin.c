#include "../inc/minishell.h"

static void	set_in(char **argv)
{
	int		fd;
	int		i;

	i = 0;
	while (argv[i] && ft_memcmp(argv[i], "<", 2))
		i++;
	if (argv[i])
	{
		fd = open(argv[i + 1], O_RDONLY, 0666);
		if (fd < 0)
		{
			ft_putstr_fd("Couldn't read from file.\n", 2);
			return ;
		}
		dup2(fd, 0);
		close(fd);
	}
}

static void	exec_bin(int fd, char *path, t_shell *param)
{
	char	**args;
	int 	i;

	i = -1;
	args = copy_args(param);
	//signal(SIGINT, child_sig_handler);
	if (!fork())
	{
		set_in(param->argv);
		if (fd > 1)
			dup2(fd, 1);
		if ((execve(path, args, param->envp)) && errno == EACCES)
		{
			param->ret = 126;
			ft_putstr_fd("bash: ", 2);
			ft_putstr_fd(param->argv[0],2);
			ft_putstr_fd(": ", 2);
			ft_putstr_fd(strerror(errno),2);
			ft_putstr_fd("\n",2);
		}
		exit(param->ret);
	}
	wait(&param->ret);
	param->ret /= 256;
	while (args[++i])
		free(args[i]);
	free(args);
//	ft_free_matrix(args);
}

static char	**split_path(t_shell *param, char *str)
{
	char *path;
	char **paths;
	path = get_env(param->envp, "PATH");

//	printf("este eraaa>>>%s<<<\n", path);
	if (path)
		paths = ft_split_case(path, ':');
	else
	{
		ft_putstr_fd("bash: ",2);
		ft_putstr_fd(str, 2);
		ft_putstr_fd(": No such file or directory\n", 2);
		param->ret = 127;
		paths = NULL;
	}
	return (paths);
}

static char	*search_bin(char *str, DIR **dir, struct dirent **d, t_shell *param)
{
	char		**paths;
	char		*path;
	int			i;

	paths = split_path(param, str);

//	printf("este es>>>%s<<<\n", *paths);
//	if (paths == NULL)
//		exit(127);
//		return (NULL);
	i = -1;
//	puts("sigue");
	if (paths != NULL)
	{
		while (paths[++i])
	{
		*dir = opendir(paths[i]);
		while ((*dir) && errno != EACCES && (*d = readdir(*dir)))
		{
			if (!ft_memcmp(str, (*d)->d_name, ft_strlen(str) + 1))
			{
				path = ft_strjoin(paths[i], "/");
				ft_free_matrix(paths);
				return (path);
			}
		}
		closedir(*dir);
	}
	ft_free_matrix(paths);
	}
	return (NULL);
}
static int	echotypes(t_shell *param)
{
	if (((param->argv[0][0] == 'e') || (param->argv[0][0] == 'E')) && 
		((param->argv[0][1] == 'c') || (param->argv[0][1] == 'C')) && 
		((param->argv[0][2] == 'h') || (param->argv[0][2] == 'H')) && 
		((param->argv[0][3] == 'o') || (param->argv[0][3] == 'O')))
	 return (0);
 else
	 return (1);
}

static int	cdtypes(t_shell *param)
{
	if (((param->argv[0][0] == 'c') || (param->argv[0][0] == 'C')) &&
		((param->argv[0][1] == 'd') || (param->argv[0][1] == 'D')))
	{
	//	write(2,"",1)
		return (0);
	}
 else
	 return (1);
}

int			check_bin(int fd, t_shell *param)
{
	DIR				*dir;
	struct dirent	*d;
	char			*pre_path;
	char			*path;
	//printf("llega aqui");
	param->ret = 127;
	if (echotypes(param) == 0)
	{	
		param->argv[0][0] = 'e';
		param->argv[0][1] = 'c';
		param->argv[0][2] = 'h';
		param->argv[0][3] = 'o';
	}
	if (cdtypes(param) == 0)
	{	
		param->argv[0][0] = 'c';
		param->argv[0][1] = 'd';
	}
	pre_path = search_bin(param->argv[0], &dir, &d, param);
	if (pre_path)
	{
		path = ft_strjoin(pre_path, d->d_name);
		//printf("path:%s\n", path);
		//printf("pre:%s\n", pre_path);
		exec_bin(fd, path, param);
		free(pre_path);
		free(path);
		closedir(dir);
	}
	//free(pre_path);
	return (param->ret);
}
