/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/02 17:37:31 by fscorcel          #+#    #+#             */
/*   Updated: 2022/07/14 18:02:47 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/minishell.h"

static char *questionme(char *env, char *str)
{
	char *tmp;
	char *tmp2;
	int x = 0;
//	printf("IENV ES%s\n", env);

	tmp =	ft_strchr(str, '?');

//	printf("TEMPI§%c\n", tmp[0]);
	tmp2 = (char *)malloc(sizeof(char) * (ft_strlen(tmp) + 1));
	while(tmp[++x])
	{
//	printf("laxesss§%c\n", tmp[x]);
		tmp2[x-1]= tmp[x];
	}
	tmp2[x] = '\0';
	free(tmp2);
	tmp = ft_strdup(tmp2);
	tmp2 = ft_strdup(env);
	free(env);	
		
	//rm_char(&tmp, 0);
    env = ft_strjoin(tmp2, tmp) ; // aca se hace el ?
	free(tmp);
	free(tmp2);

//	printf("gillll%s\n", env);
	return(env);
}
static int  change_env(int i, int braces, char **str, t_shell *shell)
{
    int     len;
    char    *bef;
    char    *aft;
    char    *env;
    char    *aux;
	
    braces = ((*str)[i + 1] == '{') ? 1 : 0;
    len = (ft_strlen_char(*str + i + 1, ':') < ft_strlen_env(*str + i + 1)) ?
    ft_strlen_char(*str + i + 1, ':') + 1 :
    ft_strlen_env(*str + i + 1) + 1 + braces;
    bef = ft_strldup(*str, i);
    aux = ft_strldup(*str + i + 1 + braces, len - 1 - braces * 2);
//	if (ft_strlen(aux) == 0)
//		puts("increibvlew");
//	printf("soyiaux--->%s<---\n\n",aux);
	/*if(ft_strchr(aux, '?'))
	{
    	env = (ft_strchr(aux, '?')) ? ft_itoa(shell->ret) : 0; // aca se hace el ?
		questionme(aux, env,*str, shell);

	}*/
    env = (ft_strchr(aux, '?')) ? ft_itoa(shell->ret) : 0; // aca se hace el ?
	if (env)
		env = questionme(env,*str);
	else
	{
		if (len > 1 )	
		{
			if(mini_getenv( aux, shell->envp, 0) != NULL)	
				env = ft_strdup(mini_getenv(aux, shell->envp, 0));
		}
		if (aux)
		{	
			if(ft_strlen(aux) == 0 )	
			{
				free(env);
				env = ft_strdup("$");
			}
		}
		else
			env = 0;
	}

//	printf("soyenv%s\n\n", env);
    aft = ft_strdup(*str + i + len);
    free(aux);
	if (env != 0)
	{

//		puts("siiiiii");

//	printf("soyiaux--->%s<---\n\n",env);
		len = ft_strlen(env);
	    aux = ft_strjoin(bef, env);
    	*str = ft_strjoin(aux, aft);

//	printf("soystrrr--->%s<---\n\n",*str);
		free(aux);
		free(aft);
	}
	else
	{
//		puts("noooooooooo");
		len = 0;
	}
	free(bef);
	free(env);
//	free(aft);
//	puts("este es el str final");
//	puts(*str);
    return (len);
}
static void dollarme(int i, char **str, t_shell *shell)
{
if ((*str)[i + 1 ]  >= '0' && (*str)[i + 1 ] <= '9')
{
	rm_char(str, i);
    rm_char(str, i);
	return ;
}

if (!(!(*str)[i + 1] || ft_isspace((*str)[i + 1]) || (*str)[i + 1] == '\'' ||
        (*str)[i + 1] == '\"' || (*str)[i + 1] == '/'))//la utilma no hace nada obviamente jajaj
{
//	puts("cambio aca");
//printf("eliantes%d", i);
            i += change_env(i, 0, str, shell) - 1;

//printf("elidespues%d", i);

//printf("elidespues%s",*str);
}

}
static int  check_quotes(char **str, int *i, t_shell *shell)
{
    (*i)++;
    while ((*str)[*i] && ((*str)[*i] != '\''))
        (*i)++;
    if (!(*str)[*i])
    {
        ft_putstr_fd("Non finished quotes\n", 2);
		shell->ret = 2;
        return (1);
    }
    return (0);
}
static void  check_quotes2(char **str, int *i, t_shell *shell)
{
	int q;
	int a =1;
	int b = -1;

	q = (*i);
	if (shell->quotflag == 1)
		return ;
    (*i)++;
//	puts("exntra");
    while ((*str)[*i] && ((*str)[*i] != '\"'))
        (*i)++;
//	printf("sali%d\n", shell->quotflag);
    if (!(*str)[*i]) //&& shell->quotflag != 1)
    {
//puts("acatoy");
//	puts(&(*str)[*i -1]);
        ft_putstr_fd("Non finished quotes\n", 2);
		shell->ret= 2;
        shell->quotflag = 3;
		return ;
    }
//	printf("hijoeputa%c\n", (*str)[q+1]);
//if (ft_strchr(*str, '$'))
//	puts(*str);
			//skip_spaces(&(*str));
//	if ((*str)[q+1] == '$')

	if (ft_strchr(*str, '$'))
		{
			while((*str)[++b])
			{
				if ((*str)[b] == '\"')
					a++;
			}
			if (a % 2 ) //|| a == 0 )
//	puts("quelorepan");
			{
				(*i) = q +1;
				shell->quotflag = 1;
			}				
			else
			{	
				ft_putstr_fd("Non finished quotes\n", 2);
				shell->ret= 2;
    		    shell->quotflag = 3;
				return ;
			}
		}
    return ;
}

static int  check_env(char **str, t_shell *shell)
{
    int i;


	shell->quotflag = 0;
    i = 0;
    while ((*str) && (*str)[i])    {

	//	printf("soyfaggg%d/\n", shell->quotflag);
        if ((*str)[i] == '\'' && check_quotes(str, &i, shell) == 1)
		{	shell->ret = 2;
            return (1);
		}
		if ((*str)[i] == '\"')
		{
		    check_quotes2(str, &i, shell); 
			if (shell->quotflag == 3)
				return(1);
		}
	//	printf("soyfaggg%d/\n", shell->quotflag);
        /*if ((*str)[i] && (*str)[i] == '\\')
        {
			puts("yvamos denuevo");
            if ((*str)[i + 1] == '$')
                rm_char(str, i);
            if ((*str)[i + 1])
                i++;
        }*/
	//	printf("%d\n\n", i);
        /*if ((*str)[i] == '\"')
		{
			i++;
		}*/
		/*if (ft_strchr(*str, '$'))
			skip_spaces(&(*str));
*/
        if ((*str)[i] == '$')
		{
			dollarme(i, str, shell);
		}
		i++;
    }
//	puts("esesteloque va\n");
//	puts(*str);
    return (0);
}
void        set_args(char **argv, char *str, int argc, t_shell *shell)
{
    int     i;
    int     len;
    i = 0;
    while (i < argc)
    {
        skip_spaces(&str);
        len = ft_strlen_arg(str);
		free(argv[i]);
        argv[i] = ft_strldup(str, len);
        rm_token(&(argv[i]), shell);
        i++;
        str += len;
        skip_spaces(&str);
	//	printf("estoenelsetargs%s\n",argv[i] );

    }
	
}
void    parser(t_shell *shell)
{
    int i;

    i = -1;
    shell->cmds = malloc(sizeof(char **) * 2);
    shell->cmds[1] = NULL;
    shell->cmds[0] = ft_strdup(shell->str);
     if (check_env(&(shell->cmds[0]), shell))
    {
        free(shell->cmds[0]);
		free(shell->argv);
		free(shell->cmds);
	 	free(shell->str);
		shell->str = 0;
        return ;
    }

    shell->argc = count_args(shell->cmds[0]);
	shell->argv = (char **)ft_calloc(sizeof(char *), (4095));
    set_args(shell->argv, shell->cmds[0], shell->argc, shell);
//	printf("estoenelparser%s\n",shell->argv[2] );
    command_or_pipe(shell);
    free(shell->cmds[0]);
	while (shell->argv[++i])
		free(shell->argv[i]);
    free(shell->argv);
    free(shell->cmds);
    free(shell->str);
    shell->str = 0;
}
