#include "../inc/minishell.h"

// static void printspecials(t_shell *shell, char c, int i)
// {
//     int x;
//     x = 0;
//     ft_putstr_fd("bash: line 1: syntax error near unexpected token `", 2);
//     if ((shell->str[i] == '<' && shell->str[i+1] == '<') || (shell->str[i] == '>' && shell->str[i+1] == '>' ))
//     {
//             x++;
//             write( 2, &shell->str[i], 2 );
//     }
//     if (x == 1 && shell->str[i+2] == '<')
//         write( 2, "<", 1);
//     if  (x == 0)
//         write( 2, &c, 1);
//     ft_putstr_fd("'\n", 2);
// }
int  lexer(t_shell *shell, int i, int x)
{
    while (shell->str[i] == ' ' || (9 <= shell->str[i] && shell->str[i] <= 13))
        i++;
    if (shell->str[i] == '|')
    {
        ft_putstr_fd("bash: line 1: syntax error near unexpected token `", 2);
        if (shell->str[i] == '|' && shell->str[i+1] == '|')
            write( 2, &shell->str[i], 2 );
        else
            write( 2, &shell->str[i], 1);
        ft_putstr_fd("'\n", 2);
        shell->ret = 258;
        return (1);
    }
    // if (shell->str[i] == '<' || shell->str[i] == '>')
    // {
    //     if ((shell->str[i] == '<' || shell->str[i] == '>')  && x == 0)
    //     {
    //         i++;
    //         lexer(shell, i, 1);
    //     }
    //     if ((shell->str[i] == '<' || shell->str[i] == '>') && x != 0)
    //         printspecials(shell, shell->str[i], i);
    //     shell->ret = 258;
    //     return(1);
    // }
    if (shell->str[i] == '\0' && x == 1)
    {       ft_putstr_fd("bash: line 1: syntax error near unexpected token `newline'\n", 2);
        shell->ret = 258;
        return(1);
    }
    return (0);
}