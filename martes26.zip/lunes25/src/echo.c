/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   echo.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lespinoz <lespinoz@student.42barcelona.com>+#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/27 12:28:54 by fscorcel          #+#    #+#             */
/*   Updated: 2022/07/02 19:37:55 by lespinoz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/minishell.h"
static int	lechon(char *str, char c)
{
	int i;
	i = 0;
	if(!ft_memcmp(str, "", 1))
		return(1);
	if (str[0]== '-' && str[1] == 'n')
		i = 2;
	while (str[i] != '\0')
	{
		if (str[i] != c)
			return (1);
		i++;
	}
	return(0);
}

static void echo_vars(char *argv, t_shell *shell, int flag)
{
	int x = 0;
	char * aux;
	aux = "";
	while (argv[x] == ' ' || (9 <= argv[x] && argv[x] <= 13))
	        x++;
	if ((argv[x] == '~' && (argv[x - 1] == '\0' || x - 1 != 0) && (argv[x + 1] == '\0' || argv[x + 1] == ' ')) && shell->expflag == 0)
	{
		aux = mini_getenv("HOME", shell->envp, 4);
		argv= "";
		ft_putstr_fd(aux, 2);
		free(aux);
		flag = 2;
	}
	if ((argv[x] == '~' && shell->expflag !=0 && flag !=2))
	{
		ft_putstr_fd("~", 2);
		flag = 2;
	}
	if (argv[x] == '~' && (argv[x - 1] == '\0' || x - 1 != 0) && argv[x + 1] == '/')
	{
		rm_char(&argv, x);
		aux = mini_getenv("HOME", shell->envp, 4);
		ft_putstr_fd(aux, 2);
		free(aux);
		flag = 2;
	}
	while (argv[x] != '$' && argv[x] != '\0')
		x++;
		//puts("aca");
	//if (argv[x] == '$')
	//{
	//	rm_char(&argv, x);
	//	puts("entra");
	//	ft_putstr_fd(argv, 2);
	//}
}
void	echo_command(t_shell *param, int fd)
{
	int i;
	int j;
	int flag;
	char * aux;

	aux = "";	
	flag = 1;
	j = 0 ;
	i=0;
	if (param->argc == 1)
	{
		write(fd, "\n", 1);
		return ;
	}
	if (!ft_memcmp(param->argv[1], "-n", 3) && param->argc == 2)
	{

		write(fd, "", 1);
	//	printf("");
		return ;
	}
	while ((param->argc > 1 && !ft_memcmp(param->argv[++i], "-n", 3))  || (param->argc >= 1 && lechon(param->argv[i], 'n') == 0))
		j ++;
	if (j != 0)
		flag = 0;
	i = -1;
	while (++j < param->argc)
	{
		echo_vars(param->argv[j], param, flag);
		if(param->argv[j][i + 1] != '~' || (param->argv[j][i + 1] == '~' && (param->argv[j][i + 2] == 'a' || param->argv[j][i + 2])))
			ft_putstr_fd(param->argv[j], fd);
		if (j < param->argc - 1)
		{
			aux = ft_strchr(param->str, '=');
	//	puts("\n");
	//	puts(aux);
	//	puts("soyyo\n");
		//	printf("%d", (int )ft_strlen(param->argv[j + 1]));
			if(ft_strlen(param->argv[j + 1]) == 0)
				write(fd, " ", 1);
			if (!(ft_strchr(param->argv[j], '=')) || (ft_strchr(param->str, '=') && aux[1] == ' '))
				write(fd, " ", 1);
		//	else 
		//		write(fd, " ", 1);
		//	free (aux);
		}
		flag = 1;
	}
	if (!(param->argc > 1 && !ft_memcmp(param->argv[1], "-n", 3)) && flag != 0)
		write(fd, "\n", 1);
	param->ret = 0;
}
