/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rick.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lespinoz <lespinoz@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/16 17:17:18 by lespinoz          #+#    #+#             */
/*   Updated: 2022/07/16 17:17:20 by lespinoz         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/minishell.h"
#include <stdarg.h>

void	print(char *str)
{
	ft_putstr_fd(str, 2);
}

void	print_end(char *str)
{
	ft_putendl_fd(str, 2);
}

void	print_red(char *str)
{
	str = ft_strjoin("\033[0;31m", str);
	str = ft_strjoin(str, "\e[0m");
	ft_putstr_fd(str, 2);
}

void	print_rick(void)
{
	print_1();
	print_2();
	print_3();
	print_4();
	print_5();
}
