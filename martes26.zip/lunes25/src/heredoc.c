/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   heredoc_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: toni <toni@student.42.fr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/12/04 21:59:04 by toni              #+#    #+#             */
/*   Updated: 2021/12/14 17:12:37 by toni             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/minishell.h"

// static int	exit_close_fds(int fd1, int fd2, int exit_status)
// {
// 	if (fd1 != -1)
// 		close(fd1);
// 	if (fd1 != -1)
// 		close(fd2);
// 	return (exit_status);
// }

// static void	wait_for_heredoc_help(t_exp_tok *exp_tok)
// {
// 	if (exp_tok->cmd == NULL && exp_tok->out != STDOUT_FILENO)
// 	{
// 		close(exp_tok->out);
// 		exp_tok->out = STDOUT_FILENO;
// 	}
// }

static int	exit_close_fds(int fd1, int fd2, int exit_status)
{
	if (fd1 != -1)
		close(fd1);
	if (fd1 != -1)
		close(fd2);
	exit(0);
	return (exit_status);
}

int	wait_for_heredoc(char **argv, char *buf, char *heredoc, int pos)
{
	int		end[2];
	int 	in;

	if (pipe(end) == -1)
		ft_putstr_fd("pipe error", 2);
	in = end[0];
	heredoc = argv[pos];
	while (15)
	{
		buf = readline("heredoc >");
		if (buf == NULL)
			return (exit_close_fds(end[1], -1, EXIT_SUCCESS));
		if (ft_memcmp(buf, heredoc, ft_strlen(heredoc)) == 0)
		{
			break ;
		}
		ft_putstr_fd(buf, end[1]);
		ft_putstr_fd("\n", end[1]);
		free(buf);
	}
	dup2(end[0], 0);
	close(end[1]);
	// else
	// {
	// 	//return (exit_close_fds(end[0], end[1], EXIT_FAILURE));
	// }
	// while (true)
	// {
	// 	buf = readline("heredoc>");
	// 	if (buf == NULL)
	// 		return (exit_close_fds(end[1], -1, EXIT_SUCCESS));
	// 	if (ft_strcmp(buf, heredoc) == 0)
	// 		break ;
	// 	ft_fprintf(end[1], "%s\n", buf);
	// 	free(buf);
	// }
	// free(buf);
	// close(end[1]);
	// wait_for_heredoc_help(exp_tok);
	return (EXIT_SUCCESS);
}
