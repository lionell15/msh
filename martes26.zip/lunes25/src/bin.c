#include "../inc/minishell.h"

static int	count_redir(t_shell *param)
{
	int	count;
	int	i;

	i = -1;
	count = 0;
	while (++i < param->argc)
	{
		if (!ft_memcmp(param->argv[i], "<", 2))
		{
			count++;
			i++;
		}
	}
	return (count);
}
static int check_files(t_shell *param)
{
	int i;
	int fd;

	i = 0;
	while(param->argv[i])
	{
		if (!ft_memcmp(param->argv[i], "<", 2))
		{
			fd = open(param->argv[i + 1], O_RDONLY, 0666);
			if (fd < 0)
			{
				ft_putstr_fd("bash: ", 2);
				ft_putstr_fd(param->argv[i+1] , 2);
				ft_putstr_fd(": No such file or directory\n", 2);
				param->ret = 1;
				return (1);
			}
			close(fd);
		}
		i++;
	}
	return(0);
}
static char **copy_args1(t_shell *param)
{
	int i;
	int count;
	char **args;
	int found;

	count = 0;
	i=-1;

	found = ft_found_in_matrix(param->argv, "<");
	args = (char **)ft_calloc(sizeof(char *), 4);
	while (param->argv[++i])
		count++;
	if (check_files(param) == 1)
	{
		exit(1);
		s_status = 1;
	}
	if (count_redir(param) > 0 && ft_memcmp(param->argv[found +1], "<", 2))
	{
			args[0] = ft_strdup(param->argv[0]);
			args[1] = ft_strdup(param->argv[1]);
			args[2] = ft_strdup(param->argv[count - 1]);
			args[3]= NULL;
			return (args);
			
	}
	return (param->argv);

}

static void	set_in(char **argv, t_shell *shell)
{
	int		fd;
	int found;
	
	if (shell->argc > 3)
		argv = copy_args1(shell);
	else
		argv = ft_dup_matrix(shell->argv);
	found = ft_found_in_matrix(argv, "<");
	if (found >=0)
	{

		if (!argv[found + 1])
		{
			ft_putstr_fd("syntax error near unexpected token `newline'\n", 2);
 			exit(1);
		}
		if (!ft_memcmp(argv[found + 1], "<", 2))
		{
			if (!argv[found + 2])
			{
				ft_putstr_fd("syntax error near unexpected token `newline'\n", 2);
	 			exit(1);
			}
			else
			{
				wait_for_heredoc(argv, NULL, NULL, found + 2);
			}
		}
		else
		{
			fd = open(argv[found + 1], O_RDONLY, 0666);
			if (fd < 0)
			{
				ft_putstr_fd("bash: ", 2);
				ft_putstr_fd(argv[found + 1] , 2);
				ft_putstr_fd(": No such file or directory3.\n", 2);
				shell->ret = 1;
				exit(shell->ret);
			}
			dup2(fd, 0);
			close(fd);
		}
	}
}

static void	exec_bin(int fd, char *path, t_shell *param)
{
	char	**args;
	int 	i;

	i = -1;
	args = copy_args(param);
	printf("ret:%d\n", param->ret);
	if (!fork())
	{
		set_in(param->argv, param);
		if (fd > 1)
			dup2(fd, 1);
		if ((execve(path, args, param->envp)) && errno == EACCES)
		{
			param->ret = 126;
			ft_putstr_fd("bash: ", 2);
			ft_putstr_fd(param->argv[0],2);
			ft_putstr_fd(": ", 2);
			ft_putstr_fd(strerror(errno),2);
			ft_putstr_fd("\n",2);
		}
		exit(param->ret);
	}
	wait(&param->ret);
	param->ret /= 256;
	while (args[++i])
		free(args[i]);
	free(args);
//	ft_free_matrix(args);
}

static char	**split_path(t_shell *param, char *str)
{
	char *path;
	char **paths;

	path = get_env(param->envp, "PATH");
	if (path)
		paths = ft_split_case(path, ':');
	else
	{
		ft_putstr_fd("bash: ",2);
		ft_putstr_fd(str, 2);
		ft_putstr_fd(": No such file or directory\n", 2);
		param->ret = 127;
		paths = NULL;
	}
	return (paths);
}

static char	*search_bin(char *str, DIR **dir, struct dirent **d, t_shell *param)
{
	char		**paths;
	char		*path;
	int			i;

	paths = split_path(param, str);
	i = -1;
	if (paths != NULL)
	{
		while (paths[++i])
	{
		*dir = opendir(paths[i]);
		while ((*dir) && errno != EACCES && (*d = readdir(*dir)))
		{
			if (!ft_memcmp(str, (*d)->d_name, ft_strlen(str) + 1))
			{
				path = ft_strjoin(paths[i], "/");
				ft_free_matrix(paths);
				return (path);
			}
		}
		closedir(*dir);
	}
	ft_free_matrix(paths);
	}
	return (NULL);
}
static int	echotypes(t_shell *param)
{
	if (((param->argv[0][0] == 'e') || (param->argv[0][0] == 'E')) && 
		((param->argv[0][1] == 'c') || (param->argv[0][1] == 'C')) && 
		((param->argv[0][2] == 'h') || (param->argv[0][2] == 'H')) && 
		((param->argv[0][3] == 'o') || (param->argv[0][3] == 'O')))
	 return (0);
 else
	 return (1);
}

static int	cdtypes(t_shell *param)
{
	if (((param->argv[0][0] == 'c') || (param->argv[0][0] == 'C')) &&
		((param->argv[0][1] == 'd') || (param->argv[0][1] == 'D')))
	{
		return (0);
	}
 else
	 return (1);
}

int			check_bin(int fd, t_shell *param)
{
	DIR				*dir;
	struct dirent	*d;
	char			*pre_path;
	char			*path;

	param->ret = 127;
	if (echotypes(param) == 0)
	{	
		param->argv[0][0] = 'e';
		param->argv[0][1] = 'c';
		param->argv[0][2] = 'h';
		param->argv[0][3] = 'o';
	}
	if (cdtypes(param) == 0)
	{	
		param->argv[0][0] = 'c';
		param->argv[0][1] = 'd';
	}
	pre_path = search_bin(param->argv[0], &dir, &d, param);
	if (pre_path)
	{
		path = ft_strjoin(pre_path, d->d_name);
		//printf("path:%s\n", path);
		//printf("pre:%s\n", pre_path);
		exec_bin(fd, path, param);
		free(pre_path);
		free(path);
		closedir(dir);
	}
	//free(pre_path);
	return (param->ret);
}
