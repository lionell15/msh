#include "../inc/minishell.h"

char		**export_command(t_shell *param, int j)
{
	int		i;
	char	**cpy;
	char *aux;

	aux="";

	i = 0;
	while (param->envp[i] && ft_memcmp(param->envp[i],
			param->argv[j], ft_strlen(param->argv[j])))
		i++;
	if (!param->envp[i])
	{
		cpy = copy_env(param->envp, 1);
		cpy[i] = ft_strjoin(param->argv[j], param->argv[j + 1]);
	}
	else
	{
		cpy = param->envp;
		aux = ft_strjoin(param->argv[j], param->argv[j + 1]);
		param->envp[i] = ft_strdup(aux);
		free(aux);
	}
	return (cpy);
}

void		export_value(t_shell *param, int *i)
{
	char	**aux;
	int		j;

	//printf("%d\n", *i);
	if (!ft_strchr(param->argv[*i], '='))
	{
		j = 0;
		while (param->export[j])
		{
			if(ft_memcmp(param->export[j], param->argv[*i], ft_strlen(param->argv[*i])))
				j++;
		}
		if (!param->export[j])
		{
			aux = copy_env(param->export, 1);
			aux[j] = ft_strdup(param->argv[*i]);
			aux[j + 1] = 0;
			ft_free_matrix(param->export);
			param->export = aux;
		}
		(*i)++;
	}
	else
	{
		param->envp = export_command(param, *i);
		*i += param->argv[*i + 1] ? 2 : 1;
	}
}

int mini_check(char *value)
{
	int found;
	found = ft_strchr_i(value, '=');
	if (value[found-1] == ' ')
		return (1);
	else
		return (0);
}

char *get_var(char *str, int found)
{
	char *value;
	int ini;
	int fi;

	ini=0;
	fi=0;
	//printf("f:%d\n", found);
	//ini = ft_strchrl(str, ' ', ini, found) + 1;
	while(str[found] != ' ')
		found--;
	ini = found+1;
	//printf("ini:%d\n", ini);
	fi = ft_strchrl(str, ' ', ini+1, ft_strlen(str))-1;
	value = ft_substr(str, ini, fi-ini+1);

	return (value);
}
void add_argv(t_shell *shell, char *value, int i, int flag)
{
	char *val;

	if (flag == 15)
	{
		free(shell->argv[i]);
		shell->argv[i] = ft_strdup("*");
		free(shell->argv[i+1]);
		shell->argv[i+1] = ft_strdup("*");
	}
	else
	{
		free(shell->argv[i]);
		shell->argv[i] = ft_substr(value, 0, ft_strchr_i(value, '=')+1);
		val =  ft_substr(value, (ft_strchr_i(value, '=')+1), ft_strlen(value));
		free(shell->argv[i+1]);
		shell->argv[i+1] = val;
	}
}

int		check_export_error(t_shell	*shell, int times)
{
	int found;
	int i;
	int j;
	char *value;
	char *str;
	i = 0;
	j=0;
	found = 0;
	str = shell->str;
	if (found >= 0)
	{
		while(i <(times*2))
		{
			
			while (str[j] != '=')
					j++;
			found = j;
			//printf("found:%d\n", found);
			if (ft_isspace(str[found -1]))
			{
				value = ft_substr(str, found, ft_strlen(&str[found]));
				ft_putstr_fd("bash: export: `", 2);
				ft_putstr_fd(value, 2);
				ft_putstr_fd(": not a valid identifier\n", 2);
				add_argv(shell, value, i, 15);
				shell->ret = 1;
			}
			if (ft_isdigit(str[found -1]))//&& ft_isdigit(str[found -2] ))
			{
				while(str[found- 1] != ' ')
					found --;
				if (ft_isalpha((int)str[found]) == 0)
				{
					value = ft_substr(str, found-1, ft_strlen(&str[found])+1);
					ft_putstr_fd("bash: line 0: export: `", 2);
					ft_putstr_fd(value, 2);
					ft_putstr_fd("': not a valid identifier\n", 2);
					add_argv(shell, value, i, 15);
					shell->ret = 1;
				}
				else
				{
					value = get_var(str, found);
					if (mini_check(value) == 0)
						add_argv(shell, value, i, 0);
				}
			}
			else
			{
				//printf("i:%d\n", i);
				value = get_var(str, found);
				// printf("value>%s<\n", value);
				if (mini_check(value) == 0)
					add_argv(shell, value, i, 0);
			}
			j++;
			i +=2;
		}
		shell->argv[i] = NULL;
	}
	return (0);
}
static void	put_envp(char **aux, int fd)
{
	int i;

	i = -1;
	while (aux[++i])
	{
		ft_putstr_fd("declare -x ", fd);
		ft_putstrlen_fd(aux[i], ft_strlen_char(aux[i], '=') + 1, fd);
		if (ft_strchr(aux[i], '='))
		{
			ft_putstr_fd("\"", fd);
			ft_putstr_fd(ft_strchr(aux[i], '=') + 1, fd);
			ft_putstr_fd("\"", fd);
		}
		write(fd, "\n", 1);
	}
	ft_free_matrix(aux);
}

void	sort_envp(char **envp, int fd, char c)
{
	int		i;
	int		len;
	char	**aux;
	char	*tmp;

	aux = copy_env(envp, 0);
	i = 0;
	while (aux[i] && aux[i + 1])
	{
		len = (ft_strlen_char(aux[i], c) > ft_strlen_char(aux[i + 1], c))
				? ft_strlen_char(aux[i], c) : ft_strlen_char(aux[i + 1], c);
		if (ft_memcmp(aux[i], aux[i + 1], len) > 0)
		{
			tmp = aux[i];
			aux[i] = aux[i + 1];
			aux[i + 1] = tmp;
			i = -1;
		}
		i++;
	}
	put_envp(aux, fd);
}
//l=1 l2=2 l3 =3 l4=4