#include "../inc/minishell.h"

int get_times(t_shell *shell)
{
	int i;
	int t;

	t=0;
	i=0;
	while (shell->str[i])
	{
		if (shell->str[i] == '=')
			t++;
		i++;
	}
	return (t);
}

static char	**multiple_env(t_shell *param, int fd)
{
	int found;
	int times;
	int i;

	i=0;
	found = ft_strchr_i(param->str, '=');
	times= get_times(param);
	param->ret = 0;
	

	if (!ft_memcmp(param->argv[0], "export", 7) && param->argc == 1 && !param->argv[1])
	{
		sort_envp(param->envp, fd, '=');
		sort_envp(param->export, fd, 0);
	}
	else if (!ft_memcmp(param->argv[0], "export", 7) && param->argv[1])
	{
		if (found >= 0)
		{
			int x=-1;
			while(param->argv[++x])
				param->argv[x]= NULL;
			if (check_export_error(param, times))
				(param->ret)++;
			else
			{
				while(param->argv[i])
				{
					if(param->argv[i][0] != '*')	
						export_value(param, &i);
					else
						i++;
				}
			}
		}
	}
	else if (!ft_memcmp(param->argv[0], "unset", 6))
	{
		i =1;
		while(param->argv[i])
		{
			//printf(">%s<\n", param->argv[i]);
			param->envp = unset_command(param, &i);
			i++;
		}

	}
	return (param->envp);
}
static void	env_command(t_shell *param, int fd)
{
	int i;

	i = 0;
	if (param->argc != 1)
	{
		ft_putstr_fd("env: ‘", 2);
		ft_putstr_fd(param->argv[1], 2);
		ft_putstr_fd("’: Permission denied\n", 2);
		param->ret = 126;
		return ;
	}
	while (param->envp[i])
	{
		ft_putstr_fd(param->envp[i++], fd);
		ft_putstr_fd("\n", fd);
	}
}

static int	check_builts(int fd, t_shell *param)
{
	char cwd[4097];

	if (!ft_memcmp(param->argv[0], "echo", 5))
		echo_command(param, fd);
	else if (!ft_memcmp(param->argv[0], "pwd", 4))
	{
		ft_putstr_fd(getcwd(cwd, 4096), fd);
		ft_putstr_fd("\n", fd);
	}
	else if (!ft_memcmp(param->argv[0], "cd", 3))
		cd_command(param);
	else
		return (1);
	return (0);
}

int			check_builtins(int fd, t_shell *param)
{
	param->ret = 0;
	if (!ft_memcmp(param->argv[0], "export", 7) ||
			!ft_memcmp(param->argv[0], "unset", 6))
		param->envp = multiple_env(param, fd);
	else if (!check_builts(fd, param))
		return (param->ret);
	else if (!ft_memcmp(param->argv[0], "env", 4))
		env_command(param, fd);
	else if (!ft_memcmp(param->argv[0], "./", 2) ||
			!ft_memcmp(param->argv[0], "../", 3) ||
			!ft_memcmp(param->argv[0], "/", 1))
		bash_command(param);
	else if (!ft_memcmp(param->argv[0], "exit", 5) ||
			!ft_memcmp(param->argv[0], "q", 2))
		exit_command(param);
	else
		return (127);
	//printf("%d\n", param->ret);
	return (param->ret);
}
