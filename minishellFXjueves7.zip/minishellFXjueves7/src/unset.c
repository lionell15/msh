#include "../inc/minishell.h"

static char	**erase_env(char **envp, int i)
{
	int		j;
	int		len;
	char	**cpy;

	len = 0;
	while (envp[len])
		len++;
	if (!(cpy = (char **)ft_calloc(sizeof(char *), len)))
		return (NULL);
	j = -1;
	while (++j < i)
		cpy[j] = ft_strdup(envp[j]);
	i++;
	while (envp[i])
		cpy[j++] = ft_strdup(envp[i++]);
	//ft_free_matrix(envp);
	return (cpy);
}

char		**unset_command(t_shell *param, int *j)
{
	int		len;
	char	**cpy;
	char *env;
	int i;
	int flag;
	
	i=0;
	flag=0;
	if (param->argc < 2)
		return (param->envp);
	while(param->argv[*j][i])
	{
		if (ft_isspace(param->argv[*j][i]) || param->argv[*j][i] == '\\')
			i++;
		if (!ft_isalnum(param->argv[*j][i]))
			flag=1;
		i++;
	}
	if (ft_strchr(param->argv[*j], ' ') || ft_strchr(param->argv[*j], '=') || flag == 1)
	{
		ft_putstr_fd("bash: unset: `", 2);
		ft_putstr_fd( param->argv[*j], 2); 
		ft_putstr_fd("': not a valid identifier\n", 2);
		param->ret = 1;
	}
	len= ft_strlen(param->argv[*j]);
	env = ft_strjoin(param->argv[*j], "=");
	i = 0;
	while (param->envp[i] && ft_memcmp(env, param->envp[i], len))
		i++;
	if (param->envp[i])
		cpy = erase_env(param->envp, i);
	else
		cpy = param->envp;
	free(env);
	return (cpy);
}