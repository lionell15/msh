#ifndef MINISHELL_H
# define MINISHELL_H

# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <fcntl.h>
# include <errno.h>
# include <dirent.h>
# include <termios.h>
# include "../libft/libft.h"
# include <readline/readline.h>
# include <readline/history.h>
# include <string.h>
#include <signal.h>
#include <sys/wait.h>


typedef struct		s_shell{
	int		argc;
	char	**argv;
	char	**envp;
	char	**export;
	int		ret;
	char	*str;
	char	**cmds;
	int		child;
	int		expflag;
	int		quotflag;
	int		equalflag;
}					t_shell;


/*readline lib*/
void 	rl_replace_line (const char *text, int clear_undo);

/*init_prompt.c*/
t_shell		init_struct(char **argv, char **envp);
t_shell		init_vars(t_shell prompt, char **argv);
char		*put_deco(t_shell *shell);

/*signals.c*/
int		set_signal(void);
int		enter_ctrld(t_shell shell);

/**/


char	**copy_env(char **envp, int add);
char	*get_env(char **envp, char *env);
/*parser.c*/
void	parser(t_shell *shell);
void        set_args(char **argv, char *str, int argc, t_shell *shell);
/*frees.c*/
void    ft_free_matrix(char **matrix);
void    rm_token(char **arg, t_shell *shell);
void    rm_char(char **str, int j);
/**/
void    ft_free_matrix(char **matrix);
/*utils.c*/
void    skip_spaces(char **str);
int     ft_strlen_arg_token(char *str, char c);
int  	ft_strlen_arg(char *str);
int     ft_strlen_char(char *str, char c);
int     ft_strlen_env(char *str);
int     count_args(char *str);
int     is_token(char c);
int		ft_matrixlen(char **m);
char    **copy_args(t_shell *param);
char	**ft_dup_matrix(char **m);
void    ft_putstrlen_fd(char *s, int len, int fd);
/*echo*/
void	echo_command(t_shell *param, int fd);
/*pipe.c*/
void	command_or_pipe(t_shell *param, int j);
/**/
void    child_sig_handler(int sig);
void    child_sig_handler_bash(int sig);
/*command.c*/
char	**check_command(char *str, t_shell *param);
/*bin.c*/
int		check_bin(int fd, t_shell *param);
/*builtin.c*/
int		check_builtins(int fd, t_shell *param);
/*exit.c*/
void	exit_command(t_shell *shell);
void 	free_struct(t_shell *shell);
/*cd.c*/
void	cd_command(t_shell *param);
/*export.c */
void	sort_envp(char **envp, int fd, char c);
void	export_value(t_shell *param, int *i);
//int		check_export_error(char **argv, int *i);
int		check_export_error(t_shell	*shell, int times);
void	export_value(t_shell *param, int *i);
char	**export_command(t_shell *param, int j);
//int			check_export_error(char **argv, int t);
/*unset.c*/
char	**unset_command(t_shell *param, int *j);
/**/
char	*get_next_line(int fd);
/*main.c*/
int	main(int ac, char *av[], char **envp);
int	ft_test(int ac, char **argv, char **envp);
int	prompt(t_shell shell,int argc, char** argv);
/*bash.c*/
void	bash_command(t_shell *shell);
/**/
int delete_element(char **array, int pos);
char	**mini_setenv(char *var, char *value, char **envp, int n);
char	*mini_getenv(char *var, char **envp, int n);

int  lexer(t_shell *shell, int i, int x);




#endif
