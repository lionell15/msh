#include "../inc/minishell.h"

char	*get_next_line(int fd)
{
	char	a[999999] = {0};
	char	*new_s;
	int		i = 0;
	if (fd < 0)
		return (NULL);
	while (read(fd, &a[i], 1) == 1)
	{
		if (a[i] == '\n')
		{
			i++;
			break;
		}
		i++;
	}
	if (!a[0])
		return (NULL);
	new_s = malloc(i + 1);
	if (!new_s)
		return (NULL);
	i = 0;
	while (a[i])
	{
		new_s[i] = a[i];
		i++;
	}
	new_s[i] = '\0';
	return (new_s);
}