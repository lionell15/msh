#include "../inc/minishell.h"

char		**export_command(t_shell *param, int j)
{
	int		i;
	char	**cpy;
	char *aux;

	aux="";

	i = 0;
	while (param->envp[i] && ft_memcmp(param->envp[i],
			param->argv[j], ft_strlen(param->argv[j])))
		i++;
	if (!param->envp[i])
	{
		cpy = copy_env(param->envp, 1);
		cpy[i] = ft_strjoin(param->argv[j], param->argv[j + 1]);
	}
	else
	{
		cpy = param->envp;
		free(param->envp[i]);
		aux = ft_strjoin(param->argv[j], param->argv[j + 1]);
		param->envp[i] = ft_strdup(aux);
		free(aux);
	}

	//	free(param->envp[i]);
	return (cpy);
}

void		export_value(t_shell *param, int *i)
{
	char	**aux;
	int		j;
	// int x = -1;
	// while(param->export[++x])
	// 	printf("%s\n", param->export[x]);
	if (!ft_strchr(param->argv[*i], '='))
	{
		j = 0;
		while (param->export[j])
		{
			if(ft_memcmp(param->export[j], param->argv[*i], ft_strlen(param->argv[*i])))
				j++;
		}
		if (!param->export[j])
		{
			aux = copy_env(param->export, 1);
			aux[j] = ft_strdup(param->argv[*i]);
			aux[j + 1] = 0;
			ft_free_matrix(param->export);
			param->export = aux;
		}
		(*i)++;
	}
	else
	{
		param->envp = export_command(param, *i);
		*i += param->argv[*i + 1] ? 2 : 1;
	}
}

int		check_export_error(char *str, int times)
{
	int found;
	char *substr;
	found = ft_strchr_i(str, '=');
	if (found >=1)
	{
		while(times !=0)
		{
			found = ft_strchr_i(str, '=');
			if (ft_isdigit(str[found -1]) || ft_isspace(str[found+ 1]) || ft_isspace(str[found -1]) || str[found -1]== '#' ||  str[found -1]== '=' || str[found -1] == '$')
			{
				ft_putstr_fd("minishell: ", 2);
				substr =ft_substr(str, found, ft_strlen(str));
				if (ft_isspace(str[found+ 1]))
					ft_putstr_fd(ft_substr(str, found+1, ft_strlen(str)), 2);
				else
					ft_putstr_fd(substr, 2);
				ft_putstr_fd("': not a valid identifier\n", 2);
				return (1);
			}
			str= ft_substr(str, found+1, ft_strlen(str));
			times--;
		}
	}
	return (0);
}

static void	put_envp(char **aux, int fd)
{
	int i;

	i = -1;
	while (aux[++i])
	{
		ft_putstr_fd("declare -x ", fd);
		ft_putstrlen_fd(aux[i], ft_strlen_char(aux[i], '=') + 1, fd);
		if (ft_strchr(aux[i], '='))
		{
			ft_putstr_fd("\"", fd);
			ft_putstr_fd(ft_strchr(aux[i], '=') + 1, fd);
			ft_putstr_fd("\"", fd);
		}
		write(fd, "\n", 1);
	}
	ft_free_matrix(aux);
}

void	sort_envp(char **envp, int fd, char c)
{
	int		i;
	int		len;
	char	**aux;
	char	*tmp;

	aux = copy_env(envp, 0);
	i = 0;
	while (aux[i] && aux[i + 1])
	{
		len = (ft_strlen_char(aux[i], c) > ft_strlen_char(aux[i + 1], c))
				? ft_strlen_char(aux[i], c) : ft_strlen_char(aux[i + 1], c);
		if (ft_memcmp(aux[i], aux[i + 1], len) > 0)
		{
			tmp = aux[i];
			aux[i] = aux[i + 1];
			aux[i + 1] = tmp;
			i = -1;
		}
		i++;
	}
	put_envp(aux, fd);
}
