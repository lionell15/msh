#include "../inc/minishell.h"

int	ft_atoy(const char *str)
{
	int			marker;
	long double	 res;
	int			x;
	long double min= -9223372036854775807;
	min= min - 1;
	x = 0;
	marker = 0;
	res = 0;
	while ((str[marker] >= '\t' && str[marker] <= '\r') || str[marker] == ' ')
		marker++;
	if (str[marker] == '-' || str[marker] == '+' )
	{
		if (str[marker] == '-')
			x = 1;
		marker ++;
	}
	while (str[marker] != '\0')
	{
		if (str[marker] >= '0' && str[marker] <= '9')
			res = (str[marker] - '0') + (res * 10);
		else
			return (1);
		marker++;
	while ((str[marker] >= '\t' && str[marker] <= '\r') || str[marker] == ' ')
		marker++;
	}
	if (x != 0)
		res = res * -1;

	if ((str[marker] == '\0' && res == 0) ||  res > 9223372036854775807 ||  res < min)
		return (1);
	return (0);
}

static int	zeroer(char *str, char c)
{
	while(*str)
	{
		if (*str != c)
			return(0);
		str ++;
	}
return (1);
}
void	exit_command(t_shell *shell)
{
	int i;
	int z;
	i = -1;
	z = 0;
	if (shell->argc == 1 || (shell->argc == 2 && zeroer(shell->argv[1], '0') == 1))
	{
		write(2,"exit\n", 5);
			exit(0);
	}
	if (shell->argc >= 2)
	{
		if ((ft_atoy(shell->argv[1]) == 0 && shell->argc == 2) || (ft_atoy(shell->argv[1]) == 1
					&& (ft_strlen(shell->argv[1]) == 2 && ((shell->argv[1][0] == '-' || shell->argv[1][0] == '+') && shell->argv[1][1] == '0'))))
		{
			write(2,"exit\n", 5);
			if(shell->argv[1][0] == '-')
				i = 255;
			else
				i = (shell->argc > 1 && shell->ret != 2)
				? ft_atoi(shell->argv[1]) : shell->ret;
			exit(i);
		}
		else
		{	if (shell->argc == 2 || ((ft_strlen(shell->argv[1]) > 20) || (shell->argv[1][0] == '-' && (ft_strlen(shell->argv[1]) > 21))) || ((ft_atoy(shell->argv[1]) == 1) &&  shell->argv[1][0] != '0'))
			{
				write(2,"exit\n", 5);
				ft_putstr_fd("minishell: exit: ", 2);
				ft_putstr_fd(shell->argv[1], 2);
				ft_putstr_fd(": numeric argument required\n", 2);
				shell->ret = 255;
				z = 3;
				exit(shell->ret);
			}
		}
	}
		if (shell->argc > 2 && shell->ret != 2)
	{
		write(2,"exit\n", 5);
		ft_putstr_fd("minishell: exit: too many arguments\n", 2);
		shell->ret = 1;
	}
	else
	{
		i = 0;
		while (shell->argc > 1 && ft_isdigit(shell->argv[1][i]))
		{
			i++;
		}
		if ((z == 1 || z == 2 ) || (shell->argv[1][0] == '-' && (ft_strlen(shell->argv[1]) != 1 && z !=3)))
		write(2,"\nexit", 5);
		i = shell->ret;
		exit(i);
	}
}