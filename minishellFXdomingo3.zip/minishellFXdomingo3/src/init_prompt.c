#include "../inc/minishell.h"

char	*put_deco(t_shell *shell)
{
	char	*out;
	char	*home;
	char	*path;
	char	cwd[4097];
	char	*aux;
	home = get_env(shell->envp, "HOME");
	getcwd(cwd, 4096);
	if (ft_memcmp(cwd, home, ft_strlen(home)))
		path = ft_strdup(cwd);
	else
		path = ft_strjoin("~", cwd + ft_strlen(home));
	aux = get_env(shell->envp, "USER");
	out = ft_strjoin("\033[1;36m", aux);
	aux = ft_strjoin(out, " ");
	free(out);
	out = ft_strjoin(aux, path);
	free(path);
	free(aux);
	aux = ft_strjoin(out, " $\033[0;0m ");
	free(out);
	return (aux);
}

t_shell	init_vars(t_shell prompt, char **argv)
{
	char	*num;
	char *str;
	str = getcwd(NULL, 0);
	prompt.envp = mini_setenv("PWD", str, prompt.envp, 3);
	free(str);
	str = mini_getenv("SHLVL", prompt.envp, 5);
	if (!str || ft_atoi(str) <= 0)
		num = ft_strdup("1");
	else
		num = ft_itoa(ft_atoi(str) + 1);
	free(str);
	prompt.envp = mini_setenv("SHLVL", num, prompt.envp, 5);
	free(num);
	str = mini_getenv("PATH", prompt.envp, 4);
	if (!str)
		prompt.envp = mini_setenv("PATH", \
		"/usr/local/sbin:/usr/local/bin:/usr/bin:/bin", prompt.envp, 4);
	free(str);
	str = mini_getenv("_", prompt.envp, 1);
	if (!str)
	{
		prompt.envp = mini_setenv("_", argv[0], prompt.envp, 1);
		free(argv[0]);
	}
	free(str);
	prompt.envp = mini_setenv("OLDPWD", "", prompt.envp, 6);

	return (prompt);
}

t_shell	init_struct(char **argv, char **envp)
{
	(void)argv;
	t_shell	shell;
	shell.envp = ft_dup_matrix(envp);
	shell.export = NULL;
	shell.argv = NULL;
	shell.cmds = NULL;
	shell.ret = 0;
	shell.str = NULL;
	shell.child = 0;
	shell.expflag = 0;
	return (shell);
}
