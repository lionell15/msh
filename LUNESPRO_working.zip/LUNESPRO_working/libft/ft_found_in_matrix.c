#include    "libft.h"

int	ft_found_in_matrix(char **matrix, char *str)
{
	int		i;

	i = 0;
	if (!matrix)
		return (-1);
	while (matrix[i])
	{
		if (!ft_memcmp(matrix[i], str, ft_strlen(str)))
			return (i);
		i++;
	}
	return (-1);
}