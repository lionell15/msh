#include "../inc/minishell.h"


int	found_it(char *str, char c)
{
	int x;

	x= -1;
while (str[++x])
{
	if (str[x]== c)
		return(1);
}
return (0);
}
void    skip_spaces(char **str)
{
    while (**str == ' ' || (9 <= **str && **str <= 13))
        (*str)++;
}

int     is_token(char c)
{
    if (c == '"' || c == '\\')
        return (1);
    return (0);
}

int     ft_strlen_arg_token(char *str, char c)
{
    int i;
    i = 0;
    while (str[i] && str[i] != c)
    {
        if (str[i] == '\\' && is_token(str[i + 1]))
            i++;
        i++;
    }
    return (i);
}

int     ft_strlen_char(char *str, char c)
{
    int i;
    i = 0;
    while (str[i] && str[i] != c)
        i++;
    return (i);
}

int     ft_strlen_env(char *str)
{
    int     len;
    len = 0;
    while (*str &&
    (ft_isalnum(*str) || *str == '{' || *str == '?' || *str == '_'))
    {
        len++;
        str++;
    }
   // if (*str == '=')
     //   len++;
    return (len);
}

int count_args(char *str)
{
    int     n;
    n = 0;
    skip_spaces(&str);
    while (*str)
    {
        skip_spaces(&str);
        n++;
        str += ft_strlen_arg(str);
        skip_spaces(&str);
    }
    return (n);
}

int  ft_strlen_arg(char *str)
{
    int i;
    i = 0;
    if (str[i] == '<' || str[i] == '>' || str[i] == '=' || str[i] == '|')
        i = (str[i] == '>' && str[i + 1] == '>') ? 2 : 1;
    else
    {
        while (str[i] && !ft_isspace(str[i]) && str[i] != '<' &&
        str[i] != '>' && str[i] != '=' && str[i] != '|')
        {
            if (str[i] == '\'' || str[i] == '"')
            {
                i++;
                i += ft_strlen_arg_token(str + i, str[i - 1]);
                if (!(str[i]))
                    return (i);
            }
            i++;
        }
        if (str[i] == '=')
            i++;
    }
    return (i);
}

char    **copy_args(t_shell *param)
{
    int     i;
    char    **args;

    i = 0;
    while (param->argv[i] && ft_memcmp(param->argv[i], "<", 2))
        i++;
    args = ft_calloc(sizeof(char *), i + 1);
    i = 0;
    while (param->argv[i] && ft_memcmp(param->argv[i], "<", 2))
    {
        args[i] = ft_strdup(param->argv[i]);
        i++;
    }
    return (args);
}

int ft_matrixlen(char **m)
{
    int i;

    i = 0;
    while (m && m[i])
        i++;
    return (i);
}

char    **ft_dup_matrix(char **m)
{
    char    **out;
    int     n_rows;
    int     i;

    i = 0;
    n_rows = ft_matrixlen(m);
    out = malloc(sizeof(char *) * (n_rows + 1));
    if (!out)
        return (NULL);
    while (m[i])
    {
        out[i] = m[i];
        if (!out[i])
        {
            ft_free_matrix(out);
            return (NULL);
        }
        i++;
    }
    out[i] = NULL;
    return (out);
}

void    ft_putstrlen_fd(char *s, int len, int fd)
{
    int i;

    if (!s || !fd)
        return ;
    i = 0;
    while (s[i] && i < len)
    {
        write(fd, &s[i], 1);
        i++;
    }
}

void free_struct(t_shell *shell)
{
    free(shell->str);
    ft_free_matrix(shell->envp);
    ft_free_matrix(shell->export);
    ft_free_matrix(shell->argv);
    ft_free_matrix(shell->cmds);
    free(shell);
}
