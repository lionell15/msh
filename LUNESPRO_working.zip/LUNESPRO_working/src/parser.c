/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parser.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/02 17:37:31 by fscorcel          #+#    #+#             */
/*   Updated: 2022/08/01 17:44:04 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/minishell.h"

static char *questionme(char *env, char *str)
{
	char *tmp;
	char *tmp2;
	int x = 0;
//	printf("IENV ES%s\n", env);

	tmp =	ft_strchr(str, '?');

//	printf("TEMPI§%c\n", tmp[0]);
	tmp2 = (char *)malloc(sizeof(char) * (ft_strlen(tmp) + 1));
	while(tmp[++x])
	{
//	printf("laxesss§%c\n", tmp[x]);
		tmp2[x-1]= tmp[x];
	}
	tmp2[x] = '\0';
	free(tmp2);
	tmp = ft_strdup(tmp2);
	tmp2 = ft_strdup(env);
	free(env);	
		
	//rm_char(&tmp, 0);
    env = ft_strjoin(tmp2, tmp) ; // aca se hace el ?
	free(tmp);
	free(tmp2);

//printf("gillll%s\n", env);
	return(env);
}
static int  change_env(int i, int braces, char **str, t_shell *shell)
{
    int     len;
    char    *bef;
    char    *aft;
    char    *env;
    char    *aux;
//puts("pasaporacagil");	
    braces = ((*str)[i + 1] == '{') ? 1 : 0;
    len = (ft_strlen_char(*str + i + 1, ':') < ft_strlen_env(*str + i + 1)) ?
    ft_strlen_char(*str + i + 1, ':') + 1 :
    ft_strlen_env(*str + i + 1) + 1 + braces;
    bef = ft_strldup(*str, i);
    aux = ft_strldup(*str + i + 1 + braces, len - 1 - braces * 2);
//	if (ft_strlen(aux) == 0)
	//	puts("increibvlew");
//	printf("soylen--->%d<---\n\n",len);
	/*if(ft_strchr(aux, '?'))
	{
    	env = (ft_strchr(aux, '?')) ? ft_itoa(shell->ret) : 0; // aca se hace el ?
		questionme(aux, env,*str, shell);

	}*/
    //env = (ft_strchr(aux, '?')) ? ft_itoa(shell->ret) : 0; // aca se hace el ?
    env = (ft_strchr(aux, '?')) ? ft_itoa(g_status) : 0;
	if (env)
		env = questionme(env,*str);
	else
	{
		if (len > 1 )	
		{
//	puts("aahhhhhhh\n");
				env = mini_getenv(aux, shell->envp, 0);

//	printf("soyaux%s\n\n", env);
		}
		if (aux && ft_strlen(aux) == 0 )
		{	
				free(env);
				env = ft_strdup("$");
		}
	}

//	printf("soyaux%s\n\n", env);
    aft = ft_strdup(*str + i + len);
    free(aux);

//	printf("soylen111--->%d<---\n\n",len);
//	printf("soybef-->%ssoyenv%ssoystr%ssoyaft%s\n\n", bef, env, *str, aft);
	if (!env )//|| ft_strlen(env)== 0)
	{
	free(*str);
	len = 0;	
   *str = ft_strjoin(bef, aft);
//	*str= ft_strdup(bef);
//	free(aft);
//	puts("noooooooooo");

//	printf("soybef-->%ssoyafts%s\n\n", bef,  aft);
//	printf("soystrrr--->%s<---\n\n",*str);
	//	len = 0;

    //	*str = NULL;
	}

	if (env != 0)
	{

	//	puts("siiiiii");
		len = ft_strlen(env);
	    aux = ft_strjoin(bef, env);
		free(*str);
    	*str = ft_strjoin(aux, aft);

//	printf("soystrrr--->%s<---\n\n",env);
		free(aux);
		free(aft);
	}
	free(bef);
	free(env);
//	free(aft);
//	puts("este es el str final");
//	puts(*str);

//	printf("soylen333--->%d<---\n\n",len);
	//g_status = 0;
    return (len);
}
static void dollarme(int i, char **str, t_shell *shell)
{
	int r;
	int status;
//	int len;


//	len = ft_strlen(*str);
	status = 0;
	r = 0;

	i = -1;


//	printf("elidespues    ---%s",*str);
	while ((*str) && (*str)[++i])
{

//printf("elcarateta%c y d%d\n",(*str)[i], i);
	if ((*str)[i] == '\"' && r%2 == 0)
	 {
		 if (status ==1)
		 	status =0;
		 else
		 	status = 1; 
	 }
	if ((*str)[i] == '\'' && status == 0)
		 r++;

	if ((*str)[i] == '$' && (*str)[i + 1 ]  >= '0' && (*str)[i + 1 ] <= '9')
	{
			rm_char(str, i);
			rm_char(str, i);
		//	return ;
	//	i-=2;
//	puts((*str));
		}
if ((*str)[i] == '$')
{
//printf("elcarateta%c\n",(*str)[i]);
		if (!(!(*str)[i + 1] || ft_isspace((*str)[i + 1]) || (*str)[i + 1] == '\'' ||
     	   (*str)[i + 1] == '\"' || (*str)[i + 1] == '/'))//la utilma no hace nada obviamente jajaj
		{
//puts("DAAAAALE\n");
//printf("FUCKKK%selnum %d\n",*str, i);
			if (r%2 ==0)
			{
        	    i += change_env(i, 0, str, shell) - 1 ;
			//	len = ft_strlen(*str);
		//	printf("elidespues%d\n",len);

			}
//printf("elidespues%selnum %d\n",*str, i);
		}
		}

	}
}
static int  check_quotes3(char *str, char c)
{
 int	x;
 int	r;
 int	q;
 int	 status;

 r= 0;
 q =0;
 x= -1;
 status = 0 ;

 while (str[++x])
 {
	 if (str[x] == '\"' && r%2 == 0)
	 {
		 if (status ==1)
		 	status =0;
		 else
		 	status = 1; 
	 }
	if (str[x] == '\'' && status == 0)
		 r++;
	else if (str[x] == '\"' && r % 2 == 0 ) //|| (str[x] == '\"' && status == 0))
		 q++;
 }

 //printf("las q son : %d y las r son : %d, ahh el status :%d\n", q, r, status); 
 if (c == 'r')
	 return (r);
 return (q);
 //printf("las q son : %d y las r son : %d, ahh el status :%d\n", q, r, status); 
}

/*static int  check_quotes(char **str, int *i, t_shell *shell)
{
//	if (shell->quotflag == 1)
//		return 0;

    (*i)++;
    while ((*str)[*i] && ((*str)[*i] != '\''))
        (*i)++;
    if (!(*str)[*i])
    {
        ft_putstr_fd("Non finished quotes55\n", 2);
		shell->ret = 2;
        return (1);
    }
    return (0);
}*/
static void  check_quotes2(char **str, int *i, t_shell *shell)
{
	int q;
	int r;
	int a =1;
	int b = *i-1;
	int c = (*i);

	q =0;
	r = 0;

	q = check_quotes3(*str, 'q');
	r = check_quotes3(*str, 'r');

 //printf("las q son : %d y las r son : %d\n", q, r ); 
	if (shell->quotflag == 1)
		return ;
    (*i)++;
//	check_quotes3(char **str);
//	puts("exntra");
    while ((*str)[*i] && ((*str)[*i] != '\"'))
        (*i)++;
//	printf("sali%d\n", shell->quotflag);
//printf("sali%s\n", *str);

//printf("QQQQi%d\n", q);
    if (!(*str)[*i] && q%2 != 0 ) //&& shell->uquotflag != 1)
    {
//puts("acatoy");
//	puts(&(*str)[*i -1]);
        ft_putstr_fd("Non finished quotes\n", 2);
		g_status= 2;
        shell->quotflag = 3;
		return ;
    }
	b = -1;
//	printf("hijoeputa%c\n", (*str)[q+1]);
//if (ft_strchr(*str, '$'))
//	puts(*str);
			//skip_spaces(&(*str));
//	if ((*str)[q+1] == '$')
//printf("QQQQi%d\n", q);

	if (ft_strchr(*str, '$'))
		{
			while((*str)[++b])
			{
				if ((*str)[b] == '\"')
				{
					(*i) = b;
					a++;
				}
			}
			while((*str)[++(*i)])
			{
				if ((*str)[*i] == '\'')
					a++;
			}

			if (a % 2 ) //|| a == 0 )
			{
			//	puts("entrosiempreidiota\n");
				(*i) = c +1;

				shell->quotflag = 1;
			}				
		//	else
		//	{
		//		check_quotes(str, &c-1 , shell);
			//	ft_putstr_fd("Non finished quotes1\n", 2);
			//	shell->ret= 2;
    		  //  shell->quotflag = 3;
			//	return ;
		//	}
		}

	if (q %2!= 0 || r%2 !=0)
		{
			ft_putstr_fd("Non finished quotes\n", 2);
			g_status= 2;
    		shell->quotflag = 3;
			return ;
		}

    return ;
}

 int  check_env(char **str, t_shell *shell)
{
    int i;


	shell->quotflag = 0;
    i = 0;
    while ((*str) && (*str)[i])   
   	{
        if (((*str)[i] == '\"' || ((*str)[i] == '\'')) && shell->quotflag != 42)
		{
		//	puts("ya");
		    check_quotes2(str, &i, shell);
		  // shell->quotflag= 42;	
			if (shell->quotflag == 3)
				return(1);
		//	puts("sigaelbaile\n");	
		}
	//	printf("soyfaggg%d/\n", shell->quotflag);
        /*if ((*str)[i] && (*str)[i] == '\\')
        {
			puts("yvamos denuevo");
            if ((*str)[i + 1] == '$')
                rm_char(str, i);
            if ((*str)[i + 1])
                i++;
        }*/
	//	printf("%d\n\n", i);
        /*if ((*str)[i] == '\"')
		{
			i++;
		}*/
		/*if (ft_strchr(*str, '$'))
			skip_spaces(&(*str));
*/
		i++;
    }
//puts("esesteloque va\n");
//	puts(*str);

	if (found_it(*str, '$') == 1)
		dollarme(i, str, shell);
//	puts("esesteloquedaaa\n");
//	puts(*str);
    return (0);
}
void        set_args(char **argv, char *str, int argc, t_shell *shell)
{
    int     i;
    int     len;
    i = 0;
    while (i < argc)
    {
        skip_spaces(&str);
        len = ft_strlen_arg(str);
		free(argv[i]);
        argv[i] = ft_strldup(str, len);
        rm_token(&(argv[i]), shell);
        i++;
        str += len;
        skip_spaces(&str);
	//	printf("estoenelsetargs%s\n",argv[i] );

    }
	
}
void    parser(t_shell *shell)
{
    int i;

    i = -1;
    shell->cmds = malloc(sizeof(char **) * 2);
    shell->cmds[1] = NULL;
    shell->cmds[0] = ft_strdup(shell->str);
     if (check_env(&(shell->cmds[0]), shell)) //whattt da fuuuu	 no hace naaaa aca
    {
        free(shell->cmds[0]);
		free(shell->argv);
		free(shell->cmds);
	 	free(shell->str);
		shell->str = 0;
        return ;
    }
//printf("estoenelparser%s\n",shell->cmds[0] );
    shell->argc = count_args(shell->cmds[0]);
	shell->argv = (char **)ft_calloc(sizeof(char *), (4095));
    set_args(shell->argv, shell->cmds[0], shell->argc, shell);
//	printf("estoenelparser%s\n",shell->argv[2] );
    command_or_pipe(shell);
//	printf("axu---%s---\n",shell->cmds[0]);
    free(shell->cmds[0]);
	i = ft_matrixlen(shell->argv);
	while (i>=0)
	{free(shell->argv[i]);
	i --;}
	free(shell->argv);
    free(shell->cmds);
	//free(shell->str);
    shell->str = 0;
}
