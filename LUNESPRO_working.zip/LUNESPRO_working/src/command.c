#include "../inc/minishell.h"

static int	redirect(t_shell *param, int i, int fd)
{
	int		ret;
	char	c;

	while (param->argv[i])
	{
		if (!ft_memcmp(param->argv[i], ">", 2))
			fd = open(param->argv[i + 1], O_RDWR | O_CREAT | O_TRUNC, 0666);
		else if (!ft_memcmp(param->argv[i], ">>", 3))
		{
			fd = open(param->argv[i + 1], O_RDWR | O_CREAT | O_APPEND, 0666);
			ret = 0;
			while ((ret = read(fd, &c, 1)))
				if (ret == -1)
				{
					write(2, "Couldn't read file\n", 19);
					break ;
				}
		}
		i++;
		if (param->argv[i] &&
		(!ft_memcmp(param->argv[i], ">>", 3) ||
		!ft_memcmp(param->argv[i], ">", 2)))
			close(fd);
	}
	return (fd);
}

static int	set_fd(t_shell *param)
{
	int		i;
	int		fd;

	i = 0;
	fd = 1;
	while (param->argv[i] && ft_memcmp(param->argv[i], ">", 2)
			&& ft_memcmp(param->argv[i], ">>", 3))
		i++;
	if (!param->argv[i])
		return (1);
	return (redirect(param, i, fd));
}

static int	count_redir(t_shell *param)
{
	int	count;
	int	i;

	i = -1;
	count = 0;
	while (++i < param->argc)
	{
		if (!ft_memcmp(param->argv[i], ">", 2) ||
			!ft_memcmp(param->argv[i], ">>", 3))
		{
			count++;
			i++;
		}
	}
	return (count);
}

static void	copy_args1(t_shell *param, char **args)
{
	int		i;
	int		j;
 
	param->argc -= count_redir(param) * 2;
	i = 0;
	j = 0;
	while (j < param->argc)
	{
		if (!ft_memcmp(param->argv[i], ">", 2) ||
			!ft_memcmp(param->argv[i], ">>", 3))
			i += 2;
		else
			args[j++] = ft_strdup(param->argv[i++]);
	}
//	printf("%d\n\n", 22);
	ft_free_matrix(param->argv);
//	free(param->argv);
	//param->argv = NULL;
//	printf("soyyolaconchadelagorra%s", param->argv[0]);
	param->argv = ft_dup_matrix(args); //REVISAR PORQUE DEJA LEAKS CUANDO HAY ;
	//free(args);
//	free(args[1]);
	free(args);
}

char		**check_command(char *str, t_shell *param)
{
	int		fd;
	char	**args;
	int found;
	int file;

	args = (char **)ft_calloc(sizeof(char *), param->argc + 1);
	if (!args)
		return (0);
	(void)str;

//	printf("chipote%d\n\n", param->expflag);
	if (param->argv[0] && *(param->argv[0]))
	{
		fd = set_fd(param);
		copy_args1(param, args);
		g_status = check_builtins(fd, param);
		found = ft_found_in_matrix(param->argv, "<");
		if (found == 0)
		{
			if (param->argv[found + 1])
			{
				if (!ft_memcmp(param->argv[found + 1], "<", 2))
				{
					if (!param->argv[found + 2])
					{
						ft_putstr_fd("syntax error near unexpected token `newline'\n", 2);
						g_status = 258;
						return (param->envp);
					}
					else
					{
						signal(SIGINT, signal_handler);
						wait_for_heredoc(param->argv, NULL, NULL, found + 2);
						g_status = 0;
						return (param->envp);
					}
				}
				else
				{
					file = open(param->argv[found + 1], O_RDONLY, 0666);
					if (file < 0)
					{
						ft_putstr_fd("No such file or directory\n", 2);
						g_status = 1;
					}
					else
						g_status = 0;
					close (file);
					return (param->envp);
				}

			}
			else
			{
				ft_putstr_fd("syntax error near unexpected token `newline'\n", 2);
				g_status = 258;
				return (param->envp);
			}
		}
		if (g_status == 127)
		{
			check_bin(fd, param);
			if (g_status == 127 && get_env(param->envp, "PATH")!= NULL)
			{
				ft_putstr_fd("bash: ", 2);
				ft_putstr_fd(param->argv[0], 2);
				ft_putstr_fd(": command not found\n", 2);
				//param->ret = 127;
				g_status = 127;
			}
		}
		if (fd != 1)
			close(fd);
	}
//	free(args);
	return (param->envp);
}
