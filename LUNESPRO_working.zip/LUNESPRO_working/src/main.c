/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lespinoz <lespinoz@student.42barcelona.com>+#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/13 12:10:46 by lespinoz          #+#    #+#             */
/*   Updated: 2022/07/25 15:37:56 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/minishell.h"

int	ft_test(int argc, char **argv, char **envp)
{
	char		*input;
	t_shell		shell;

	(void)argc;
	shell = init_struct(argv, envp);
	if (set_signal())
		return (1);
	input = ft_strdup(argv[2]);
	shell.str = ft_strdup(input);
	if (!lexer(&shell, 0, 0))
		parser(&shell);
	return (g_status);
}

int	prompt(t_shell shell,int argc, char** argv)
{
	char	*deco;
	char	*input;

	while (15)
	{
		deco = put_deco(&shell);
		if (argc == 1)
			input = readline(deco);
		else if (argc == 2)
			input = ft_strdup(argv[1]);
		free(deco);
		if (!input)
		{
			return (enter_ctrld(shell));
		}
		else if (*input != '\0')
		{
			shell.argv = NULL;
			shell.str = ft_strdup(input);
			add_history(input);
		//	free(shell.str);
			if (!lexer(&shell, 0, 0))
				parser(&shell);
			free(shell.str);
		//	free(input);
		}
		free(input);
		free (shell.str);
	} 
	return (0);
}

int	main(int ac, char *av[], char **envp)
{
	t_shell	shell;
	int		exit_status;
	
	g_status = 0;
	if (ac >= 3 && !ft_strncmp(av[1], "-c", 3))
	{
		exit_status = ft_test(ac, av, envp);
		exit(exit_status);
	}

	shell = init_struct(av, envp);
	shell = init_vars(shell, av);
	if (set_signal())
		return (1);
	if (prompt(shell, ac, av))
		return (1);
	int i = 0;
	while (shell.envp[i])
	{
		free (shell.envp[i]);
		i++;
	}
	free(shell.str);
	return (0);
}
