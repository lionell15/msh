/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   export.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fscorcel <fscorcel@student.42barcel>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/27 14:33:20 by fscorcel          #+#    #+#             */
/*   Updated: 2022/08/01 17:48:07 by fscorcel         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../inc/minishell.h"

/*void  reloka(t_shell *shell, char *aux, int begin, int finish)
{
char *start;
char *end;
char *all;
int x;
int r;

//finish = 0;
r=0;
x = -1;
//printf("\nlaconchadelagorra%s\n", aux);
while (aux[++x])
{

	if (aux[x] == '$')
	{
		r++;
		if (shell->dollar < r)
		{

			begin = x;
			while (aux[x])
		{
		if (aux[x] == '\'' ||aux[x] == '\"' || aux[x+1] == '$' || aux[x] == ' ')
			{
			if (aux[x] == '\'' ||aux[x] == '\"' || aux[x] == ' ')
				finish = x;
			else
					finish = x+1;
			break;
			}
			x++;
			if (aux[x] =='\0')
			{
				finish = x;
				break;
			}
		}}
		
	}
	if (finish > 0)
		break;
	

}
if (shell->dollar == r && r != 0)
{
	free(shell->argv[1]);
	shell->argv[1] = ft_strdup(aux);
//	aux = NULL;
		free(aux);
//	puts("CONQUEESASTENEMOSAMIGUITOOOO");
//	printf("\nlaconchadelagorra%s\n", aux);
	return;
}
//puts("CONQUEESASTENEMOSAMIGUITOOOO");
//if (x == (int)ft_strlen(aux))
//	begin = 0;
//	printf("BEGINesssss%d\n",(int)ft_strlen(aux));
//	printf("xesssss%d\n",x);
//	printf("finish%d\n",finish);
start= ft_substr(aux, 0, begin);
if (start == NULL)
	start = ft_strdup("");
end = NULL;
if (finish!= 0)
{
end= ft_substr(aux, finish, ft_strlen(aux));
x = ft_strlen(aux);
	
//printf("laconchadelstart%s\n", start);
while (aux[finish] !='\0' && finish != 0)
{
//	printf("oyyoooo%c", aux[finish]);
	rm_char(&aux,finish );
}
}

if (end == NULL)
	end = ft_strdup("");

//printf("laconchademiiiiiil%s\n", aux);
x=0;
while (x <= begin )
{
//	printf("auxrotoessss%c\n",aux[x]);
	rm_char(&aux,x);
begin --;
}

//printf("laconchademaaal---%s---\n", aux);
//	printf("alllll%s\n",aux);
all = mini_getenv( aux, shell->envp, 0);
if(!all) //&& ft_strlen(param->argv[j+1])!=0)
{
//	puts("----->>>>");
//puts(aux);

	if(ft_strlen(aux) == 0)
	{
//puts("salchicha");

		all= ft_strdup("$");
		shell->dollar +=1;
	}
	else
	{
//puts("salchicho");
		all= ft_strdup("");
//		printf("adawdwadadw%d", (int)ft_strlen(all));
	}
}
free(aux);
//printf("alllll%s\n",start);
aux = ft_strjoin(start, all);

//printf("alllll%s\n",aux);
free(start);
free(all);
start = NULL;

//printf("ennnnnd---%s--\n",end);
if (end[0] != '\0')
{
//	puts("uiijaaa");
//	printf("JAPON%s\n", start);
	start = ft_strjoin(aux, end);
}

//printf("start---%s---\n",start);
free(end);
if (start)
{
//	puts("pijocha");
free(aux);
aux = ft_strdup(start);
free(start);
}
if (shell->dollar != r || r == 0)
{
//	puts("obvio");
//printf("elazorro%s-----\n",aux );

free(shell->argv[1]);
shell->argv[1] = ft_strdup(aux);
//free(aux);
//printf("elazorro----%s-----\n",aux );
}

//free(start);
//printf("elazorro%c-----\n",aux[x] );
//printf("elprimero%s-----\n/dolar", aux);
//printf("elultimoquesale es %s-----\n", aux);
if (found_it(aux, '$') != 0)
{//printf("elprimero%s-----\n/dolar", aux);
		reloka(shell, aux,0,0);}
}
*/

void	export_command(t_shell *param, int j)
{
	int		i;
	char	**cpy;
	char *aux;

	param->quoted = 0;
param->dollar = 0;
param->errorme= 0;
param->done = 0;

	aux=ft_strdup(param->argv[j+1]);
//printf("ELARGVVVVV J + 1111   ---- >>> %s--%d---\n", param->argv[j+1], j);

//printf("ELARGVVVVV 1111   ---- >>> %s--%d---\n", param->argv[1], j);
	i = -1;
	if (found_it(aux, '$') == 1)
	{
	param -> done = 1;
	check_env(&(param->argv[j+1]), param);
		//printf("QUECARAJOOOO\n"); 
	//	reloka(param, aux,0,0);
	//	printf("ELARGVVVVV    ---- >>> %s-----\n", param->argv[1]);
//free(aux);
       // param->expflag = 1;
}
//printf("pija%d--\n", j);
//	rm_token_ex(&param->argv[j+1], param);
//	if (found_it(param->argv[j+1], '\"') == 1)
				rm_token(&param->argv[j+1], param);

//	rm_token(&param->argv[1], param);

i=0;


//printf("elaxuquequedaaa----%s-----\n", param->argv[j+1]);

	while (param->envp[i] && ft_memcmp(param->envp[i],
			param->argv[j], ft_strlen(param->argv[j])))
	{
//printf("elaENVP[I]----%s-----\n", param->envp[i]);

//printf("elARGV[J]----%s-----\n", param->argv[j]);

		i++;}
	if (!param->envp[i])
	{
//printf("elJ+1---%s-  EL 1  -%s---\n", param->argv[j+1], param->argv[1]);
	//	printf("QUECARAJAAA\n");
		cpy = copy_env(param->envp, 1);
		free(cpy[i]);
		cpy[i] = ft_strjoin(param->argv[j], param->argv[j+1]);
	//	ft_free_matrix(param->envp);
/*i=	ft_matrixlen(param->envp) ;
int x= -1;
while(++x < i)
	free(param->envp[x]);
free(param->envp);}*/
//printf("tamaniooo%d\n", i);
//	free(aux);
	}
	else
	{
//printf("QUECARAJOOO\n");
//	if (aux)
//		free(aux);
//	puts("chiflete\n");
//printf("ELARGVVVVV J + 1111   ---- >>> %s--%d---\n", param->argv[j+1], j);

//printf("ELARGVVVVV 1111   ---- >>> %s--%d---\n", param->argv[1], j);

//		rm_token(&param->argv[1], param);
	//	free(aux);
	//	free(aux);
		aux = ft_strjoin(param->argv[j], param->argv[j+1]);
	//	free(param->envp[i]);
		param->envp[i] = ft_strdup(aux);
		cpy = copy_env(param->envp, 1);
		//cpy = ft_dup_matrix(param->envp);
	//	ft_free_matrix(param->envp);
	free(aux);
	}
	
//free(aux);
//ft_free_matrix(param->envp);
//printf("tamaniooodeenvp%d\n", i);
//puts("	CHIMUUUU  ");
//ft_free_matrix(param->envp);

//ft_free_matrix(param->envp);
//param->envp =ft_dup_matrix(cpy);
param->envp = copy_env(cpy, 0);
ft_free_matrix(cpy);
}

void		export_value(t_shell *param, int *i)
{
	char	**aux;
	int		j;
//puts("entro");
	if (!ft_strchr(param->argv[*i], '='))
	{
		j = 0;
		while (param->export[j])
		{
			if(ft_memcmp(param->export[j], param->argv[*i], ft_strlen(param->argv[*i])))
			{
		//		puts("sera\n");
				j++;
			}
		}
		if (!param->export[j])
		{
		//	puts("nosera\n");
			aux = copy_env(param->export, 1);
			aux[j] = ft_strdup(param->argv[*i]);
			aux[j + 1] = 0;
			ft_free_matrix(param->export);
			param->export = aux;
		}
		(*i)++;
	}
	else
	{
if (param->export[0])
		{
		//	puts("noloseeee");
		//	if(!ft_memcmp(param->export[0], param->argv[0], ft_strlen(param->argv[0])))// && !ft_memcmp(param->export[1], param->argv[1], ft_strlen(param->argv[1] )))
		//		puts("FUCKKKKK");
			aux = copy_env(param->export, 1);
			aux[0] = ft_strdup(param->argv[*i]);
			aux[0 + 1] = 0;
			ft_free_matrix(param->export);
			param->export = aux;
		}
if (!param->export[0])
		{

		//	puts("ioseeee");
			aux = copy_env(param->export, 1);
			aux[0] = ft_strdup(param->argv[*i]);
			aux[0 + 1] = 0;
			ft_free_matrix(param->export);
			param->export = aux;
		}
	//	puts("acahayalgo");
	
//printf("mecagoenmi%s\n",param->argv[0]);
//printf("mecagoenvos%s\n",param->argv[1]);
		 export_command(param, *i);
		*i += param->argv[*i + 1] ? 2 : 1;
	}
	}

char *mini_check(char *value)
{
//printf("VALUE DE ADD es :   %s-----\n", value);

	int found;
	found = ft_strchr_i(value, '=');
	
	if (value[found-1] == ' ' || value[found-1] == '$')
		return (NULL);
//	printf("minicheckdice:%s\n",value);
	return (value);
}

static int found_quotes(char *str,  int found)
{
int i;
int x;

x = 0;
while (str[found])
{
	if (str[found] != '=')
		found++;
	else
		break;
}
i = found;  // tengo la posisicon del primer =
//printf("entra al get var--%s---found es: %d--\n", str, found);
while (str[++found]) // busco del igual en adelante por las "
{
	if (str[found] == '\"')
		x++;
}
if (x % 2 != 0)
	x = 1;
else
	x = 0;
while (str[i])
{
	if (str[i] == '\"')
		x++;
	if (str[i] == ' ' && x % 2 == 0)
		break;
	i++;
}
//	puts("esdiferente a 0");
//printf("el espacio esta en : %d--y el anterior es :%c\n",i, str[i-1]);
return(i);
}
char *get_var(char *str, int found)
{

	char *value;
	int ini;
	int fi;
	int i;
	int j;

	j=0;
	ini=0;
	fi=0;
	i=0;
	j = found;

	while(str[found] != '=')
		found++;
	i = found_it(str, '\"');
	if (i == 1)
		fi = found_quotes(str, j);

//printf("el espacio esta en : %d--y el anterior es :%c\n",fi, str[fi-1]);
	found = j;
	while(str[found] != ' ')
		found--;
//	printf("strdeloritooo%c\n",str[found+1]); // ecnuentra la variable
	ini = found+1;

//	printf("strdelOGT%c\n",str[found+1]); // ecnuentra la variable
	if (i== 0)
	{
		fi = ft_strchrl(str, ' ', ini+1, ft_strlen(str))-1;// encunetra el valor

	value = ft_substr(str, ini, fi-ini+1);
//	printf("strdeloritooo%d\n",fi); // ecnuentra la variable
	}
	else
	{
//printf("entra al get var--%s---found es: %d--\n", str, found);
		value = ft_substr(str, ini, fi-ini+1);
	}

//printf("SALE al get var--%s---\n", value);
	return (value);
}
void add_argv(t_shell *shell, char *value, int i, int flag)
{
	char *val;
	int x;

	x =0;
val = NULL;
	if (flag == 15)
	{
	//	puts("eslaflagagatiii");
	//	free(shell->argv[i]);
		shell->argv[i] = ft_strdup("*");
	//	free(shell->argv[i+1]);
		shell->argv[i+1] = ft_strdup("*");
	//	free(value);
	}
	else
	{
	int found;
	found = ft_strchr_i(value, '=');
	
	if (value[found-1] == ' ' || value[found-1] == '$')
		return ;
	x = found;

	while (value[--found])
	{
		if (value[found] == '$')
			break;

	}
	//printf("FOUNDIIIIES%d\n", found);
	if (found < 0)
		{
		//	puts("\ndeuna\n");
found =-1;
	//	puts(shell->argv[i]);
		shell->argv[i] = ft_substr(value, 0, ft_strchr_i(value, '=')+1);
	//	printf("otroooo%s-----\n", shell->argv[i]);
		val =  ft_substr(value, (ft_strchr_i(value, '=')+1), ft_strlen(value));
	//	printf("otroooo%s-----\n", val);

	//	free(shell->argv[i+1]);
		while(shell->argv[i][++found])
		{
			if (shell->argv[i][found] == '\\')
			{
				rm_char(&shell->argv[i],found);
			//	found --;
			}
		}
		found =-1;
		while(shell->argv[i][++found])
		{
			if (shell->argv[i][found] == '\\')
			{
				ft_putstr_fd("bash: export: `", 2);
				write(2,shell->argv[found], 1);
			//	ft_putstr_fd(value, 2);
				ft_putstr_fd(": not a valid identifier\n", 2);
				shell->errorme= 1;
				add_argv(shell, value, i, 15);
				g_status = 1;
				rm_char(&shell->argv[i],found);
			//	found --;
			}
		}
		shell->argv[i+1] = ft_strdup(val);
		free(val);
//	printf("otroooo%s-----\n", shell->argv[i]);
//			printf("otraaaa%s",value);
//
found =-1;
		}
	else //NOENTRAAAA!
	{
//puts("NOENTRAAAA!");
		val =ft_substr(value,found, x-found);
	//	printf("elprimero%s-----\n", val);
		rm_char(&val, 0);
		if(mini_getenv( val, shell->envp, 0) == NULL) //&& ft_strlen(param->argv[j+1])!=0)
				val= ft_strdup("");
		else
			val = mini_getenv( val, shell->envp, 0);
	//	printf("elprimero%s-----\n", val);
		x = -1;
while (val[++x])
{
			if (ft_isalnum((int)val[x]) == 0 && val[x] != '=') //ARREGLADOOOO SOLO DAR ERROR y que siga viendo los siguientes!
			{
				value = "*";
			//	puts("telodije");
						ft_putstr_fd("bash: line 0: export: `", 2);
						ft_putstr_fd("': not a valid identifier\n", 2);
						g_status = 1;
				shell->errorme= 1;
						break ;
			//	return ;
			}
}
	//		if (value[0] != '*')
//{
			shell->argv[i] = ft_strjoin(ft_substr(value, 0, ft_strchr_i(value, '$')), val);
			free(val);
			val = ft_strjoin(shell->argv[i], "=");
		//	printf("etequedaaa%s-----\n", val);
		//	printf("etequedaaa%s-----\n", val);
			free(shell->argv[i]);
			shell->argv[i] = ft_strdup(val);
			free(val);
			val =  ft_substr(value, (ft_strchr_i(value, '=')+1), ft_strlen(value));
		//	free(shell->argv[i+1]);
			shell->argv[i+1] = ft_strdup(val);
			free(val);
	//		free(value);
		//	printf("otroooo%s-----\n", val);
		//	printf("otraaaa%s", shell->argv[i]);
//		}
		}
//free(val);
/* REVISAR QUE CUANDO DEVUELVA ALGO QUE TENGA / / O LA CHOTA NO LO HAGA*/
	}
}

int		check_export_error(t_shell	*shell, int times)
{
	int found;
	int i;

	int j;
	char *value;
	char *str;
	i = 0;
	j=0;

	found = 0;
	str = shell->str;
	if (found >= 0)
	{
		while(i <(times*2))
		{

		g_status = 0;
			g_status = 0;
			while (str[j] && str[j] != '=' )
					j++;
			found = j;
		//	printf("dondeverga esta la J%d\n", j);
			if (ft_isspace(str[found -1]))// || ft_isspace(str[found +1]))
			{
			//	puts("carapija");
				value = ft_substr(str, found, ft_strlen(&str[found]));
				ft_putstr_fd("bash: export: `", 2);
				write(2,&str[found-1], 1);
			//	ft_putstr_fd(value, 2);
				ft_putstr_fd(": not a valid identifier\n", 2);

				shell->errorme= 1;
				add_argv(shell, value, i, 15);

				g_status = 1;
			}
			if (str[found -1] == '_' && str[found-2] == ' ')
			{
				add_argv(shell, value, i, 15);
				shell->errorme = 1;
				shell->expspecial = 42;
			}
			if (ft_isdigit(str[found -1])&& !ft_isspace(str[found +1]))//&& ft_isdigit(str[found -2] ))
			{
			//	puts("heyyy!");
					while(str[found- 1] != ' ')
					{
						if (ft_isalnum(str[found-1]) == 0)// && str[found-1] != '$')
							g_status = 1;
						if (g_status == 1)
							break ;
						found --;
					}
					if (ft_isalpha((int)str[found]) == 0)
					{

			//	puts("hooyyy!");
						value = ft_substr(str, found-1, ft_strlen(&str[found])+1);

						ft_putstr_fd("bash: line 0: export: `", 2);
						write(2,&str[found], 1);
						ft_putstr_fd("': not a valid identifier\n", 2);

				shell->errorme= 1;
						add_argv(shell, value, i, 15);

						g_status = 1;
					}
					else
					{

			//	puts("haayy!");
						value = get_var(str, found);

						if (mini_check(value) != NULL)
							add_argv(shell, value, i, 0);
						free(value);
					}
			}

			else
			{
				//printf("elcaracterlocoes%c", str[found-1]);
				while(str[found- 1] != ' ')
					{
						if (str[found-1] == '\"')
							rm_char(&str, found -1);
						if (ft_isalnum(str[found-1]) == 0 && (str[found-1] != '$' || str[found-1] != '\'' ))
						{
						if (str[found-1] != '=' && str[found-1] != '$' && str[found-1] != '_' && str[found-1] != '\\')
						{
						value = ft_substr(str, found-1, ft_strlen(&str[found])+1);
						ft_putstr_fd("bash: line 0: export: `", 2);
						write(2,&str[found-1], 1);
						ft_putstr_fd("': not a valid identifier\n", 2);

				shell->errorme= 1;
						add_argv(shell, value, i, 15);
						g_status = 1;
						break ;
						}
						}
						found --;
					}
				//	printf("ERRORME----%d\n",shell->errorme);
				if (g_status != 1 && shell->errorme != 1)
					{

//printf("-LUEEUEEUUEEUEUEU---%s\n",str);
					value = get_var(str, found);

				
					//	value = ft_substr(str, found, ft_strlen(&str[found])+1);

//printf("-iVALUUUUUUEEE---%s\n",value);

//puts("ioooooosoyyy\n");
//printf("-LUEEUEEUUEEUEUEU---%s",value);

						if (mini_check(value) != NULL)
						{
							add_argv(shell, value, i, 0);
}

						else
{

						free(value);
						value = ft_substr(str, found-1, ft_strlen(&str[found])+1);

			//	printf("valuuuuuueeeee1111----%s----\n",value);
						ft_putstr_fd("bash: line 0: export: `", 2);
						write(2,"$", 1);
						ft_putstr_fd("': not a valid identifier\n", 2);

				shell->errorme= 1;
						add_argv(shell, value, i, 15);

						g_status = 1;
						}

						free(value);
					}
			}
//printf("estoesjoda%s\n", value);
//free(value);
			j++;
			i +=2;
		}
		shell->argv[i] = NULL;
	}

	return (0);
}

static void	put_envp(char **aux, int fd)
{
	int i;

	i = -1;
	while (aux[++i])
	{
		ft_putstr_fd("declare -x ", fd);
		ft_putstrlen_fd(aux[i], ft_strlen_char(aux[i], '=') + 1, fd);
		if (ft_strchr(aux[i], '='))
		{
			ft_putstr_fd("\"", fd);
			ft_putstr_fd(ft_strchr(aux[i], '=') + 1, fd);
			ft_putstr_fd("\"", fd);
		}
		write(fd, "\n", 1);
	}
	ft_free_matrix(aux);
}

void	sort_envp(char **envp, int fd, char c)
{
	int		i;
	int		len;
	char	**aux;
	char	*tmp;

	aux = copy_env(envp, 0);
	i = 0;
	while (aux[i] && aux[i + 1])
	{
		len = (ft_strlen_char(aux[i], c) > ft_strlen_char(aux[i + 1], c))
				? ft_strlen_char(aux[i], c) : ft_strlen_char(aux[i + 1], c);
		if (ft_memcmp(aux[i], aux[i + 1], len) > 0)
		{
			tmp = aux[i];
			aux[i] = aux[i + 1];
			aux[i + 1] = tmp;
			i = -1;
		}
		i++;
	}
	put_envp(aux, fd);
}
